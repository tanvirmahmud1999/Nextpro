<?php
function control_agency_default_types_options() {
    return [
        [
            'name' => esc_attr__('Upcoming', 'control-agency'),
            'slug' => 'upcoming',
        ],
        [
            'name' => esc_attr__('Active', 'control-agency'),
            'slug' => 'active',
        ],
        [
            'name' => esc_attr__('Past', 'control-agency'),
            'slug' => 'past',
        ]
    ];
}

if (!function_exists('control_agency_setting')) :
    /**
     * 
     * @param 	string	$setting_id		(required)
     * @param 	mixed	$default 		NULL
     * 
     * @return	mixed	
     */
    function control_agency_setting($setting_id, $default = NULL) {
        global $control_agency_options;
        if (array_key_exists($setting_id, $control_agency_options)) {
            return $control_agency_options[$setting_id];
        }
        return $default;
    }
endif;

if (!function_exists('control_agency_option')) :
    /**
     * 
     * @param 	string	$option_id		(required)
     * @param 	mixed	$default 		NULL
     * 
     * @return	mixed	
     */
    function control_agency_option($option_id, $default = NULL) {
        global $control_agency_options;        
        if (!empty($control_agency_options) && array_key_exists($option_id, $control_agency_options)) {
            return $control_agency_options[$option_id];
        }
        return $default;
    }
endif;

if (!function_exists('control_agency_post_type_option')) :
    /**
     * 
     * @param 	string	$option_id		(required)
     * @param 	mixed	$default 		NULL
     * 
     * @return	mixed	
     */
    function control_agency_post_type_option($option_id, $default = NULL, $post_type = NULL) {
        $post_type = empty($post_type) ? get_post_type() : $post_type;
        $option_id = $post_type . "_{$option_id}";
        return control_agency_option($option_id, $default);
    }
endif;

if (!function_exists('control_agency_formated_content')) :
    /**
     * 
     * @param 	string		$content		(required)
     * @param 	string		$before			empty
     * @param 	string		$after			empty
     * @param 	boolean		$echo 			true
     * 
     * @return	string	
     */
    function control_agency_formated_content($content, $before = '', $after = '', $echo = true) {

        $content = wp_kses_post($content);

        if (strlen($content) == 0) {
            return;
        }

        $content = $before . $content . $after;

        if ($echo) {
            echo wp_kses_post($content);
        } else {
            return $content;
        }
    }
endif;



if (!function_exists('control_agency_content')) :
    /**
     * 
     * @param 	string		$content		(required)
     * @param 	string		$before			empty
     * @param 	string		$after			empty
     * @param 	boolean		$echo			true
     * 
     * @return	string	
     */
    function control_agency_content($content, $before = '', $after = '', $echo = true) {

        if (strlen($content) == 0) {
            return;
        }
        $content = nl2br($content);

        $content = $before . $content . $after;

        if ($echo) {
            echo $content;
        } else {
            return $content;
        }
    }
endif;

if (!function_exists('control_agency_css_class')) :
    /**
     * 
     * @param 	mixed		$class		(required) allow string or array variable
     * @param 	string		$before		(optional) default:empty
     * @param 	string		$after		empty
     * @param 	boolean		$echo		true
     * 
     * @return	string	
     */
    function control_agency_css_class($class, $before = '', $after = '', $echo = true) {
        if (is_array($class)) {
            $class = array_unique(array_filter($class));
            $class = implode('', $class);
        }

        if (strlen($class) == 0) {
            return;
        }

        $class = esc_attr($class);

        $class = $before . $class . $after;

        if ($echo) {
            echo esc_attr($class);
        } else {
            return $class;
        }
    }
endif;

if (!function_exists('control_agency_button_html')) :
    /**
     * 
     * @param 	array		$button		(required)
     * @param 	string		$prefix		empty
     * @param 	boolean		$echo		true
     * 
     * @return	string	
     */
    function control_agency_button_html($button, $prefix = '', $echo = true) {
        $button = wp_parse_args($button, [
            $prefix . 'text' => 'Watch Video',
            $prefix . 'url' => '',
            $prefix . 'style' => '',
            $prefix . 'data' => '',
            $prefix . 'extra_class' => '',
            $prefix . 'video' => ''
        ]);

        if (empty($button[$prefix . 'text']) || empty($button[$prefix . 'url'])) return;

        $classes = array_filter([trim($button[$prefix . 'style']), trim($button[$prefix . 'extra_class'])]);
        if (!empty($button[$prefix . 'video']))  $classes[] = 'video-link';
        $content = sprintf(
            '<a class="btn %3$s" href="%2$s"%4$s>%1$s</a>',
            esc_attr($button[$prefix . 'text']),
            esc_url($button[$prefix . 'url']),
            implode(' ', $classes),
            !empty($button[$prefix . 'data']) ? ' ' . $button[$prefix . 'data'] : ''
        );

        if ($echo) {
            echo wp_kses_post($content);
        } else {
            return $content;
        }
    }
endif;


if (!function_exists('control_agency_meta_values')) :
    /**
     * 
     * @param 	string		$key		(optional)
     * @param 	string		$type		ctrl_projects
     * @param 	string		$status		publish
     * 
     * @return	array	
     */
    function control_agency_meta_values($key = '', $type = 'ctrl_projects', $status = 'publish') {

        global $wpdb;

        if (empty($key))
            return;

        $r = $wpdb->get_results($wpdb->prepare("
        SELECT pm.meta_value, pm.post_id FROM {$wpdb->postmeta} pm
        LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = %s 
        AND p.post_status = %s 
        AND p.post_type = %s
    ", $key, $status, $type), ARRAY_A);

        return array_column($r, 'meta_value', 'post_id');
    }
endif;



if (!function_exists('control_agency_get_terms')) :
    /**
     * 
     * @param 	string		$separator		(optional)
     * @param 	string		$taxonomy		project_cat
     * @param 	boolean		$echo			true
     * 
     * @return	string	
     */
    function control_agency_get_terms($args = [], $echo = true) {
        extract(wp_parse_args($args, [
            'separator' => ', ',
            'taxonomy' => 'project_cat',
            'wrapper_class' => 'd-flex flex-wrap gap-1',
            'wrapper_tag' => 'div',
            'link_class' => '',
            'slug' => false,
            'disable_links' => false,
            'slice' => false,
            'slice_count' => 2,
        ]));
        // Get the term IDs assigned to post.
        $post_terms = wp_get_object_terms(get_the_ID(), $taxonomy, array('fields' => 'ids'));
        if (!empty($post_terms) && !is_wp_error($post_terms)) {
            if (is_numeric($slice)) {
                $post_terms = array_slice($post_terms, $slice, $slice_count);
            }

            $term_ids = implode(', ', $post_terms);

            if ($slug) {
                $disable_links = true;
                $wrapper_class = false;
                $terms = '';
                foreach ($post_terms as $term_id) {
                    $term = get_term($term_id, $taxonomy);
                    $terms .= $term->slug . '<br />';
                }
            } else {
                $terms = wp_list_categories(array(
                    'title_li' => '',
                    'style'    => 'none',
                    'echo'     => false,
                    'taxonomy' => $taxonomy,
                    'include'  => $term_ids
                ));
            }





            $terms = rtrim(trim(str_replace('<br />',  $separator, $terms)), $separator);

            if ($disable_links) {
                $terms = strip_tags($terms);
            }
            if (!empty($link_class)) {
                $terms = rtrim(trim(str_replace('<a href=',  '<a class="' . esc_attr($link_class) . '" href=', $terms)), $separator);
            }

            if (!empty($wrapper_class)) {
                $terms = '<' . $wrapper_tag . ' class="' . esc_attr($wrapper_class) . '">' . $terms . '</' . $wrapper_tag . '>';
            }


            // Display post categories.
            if ($echo) {
                echo wp_kses_post($terms);
            } else {
                return $terms;
            }
        }
    }
endif;

if (!function_exists('control_agency_ordering_options')) :
    /**
     * 
     * @param 	boolean		$single		false
     * 
     * @return	array	
     */
    function control_agency_ordering_options($single = false) {
        $args = array(
            'date'       => __('Sort by Date', 'control-agency'),
            'atoz'      => __('Sort by Title (A-Z)', 'control-agency'),
            'ztoa'      => __('Sort by Title (Z-A)', 'control-agency'),
        );
        if ($single) {
            return !empty($arg[$single]) ? $arg[$single] : NULL;
        }
        return $args;
    }
endif;


if (!function_exists('control_agency_archive_page_url')) :
    /**
     *  
     * @return	string|false	
     */
    function control_agency_archive_page_url($current_url = false) {
        if ($current_url && is_tax('project_cat') && !empty(get_queried_object())) {
            return get_term_link(get_queried_object()->term_id, 'project_cat');
        }
        if ($current_url && is_tax('project_tag') && !empty(get_queried_object())) {
            return get_term_link(get_queried_object()->term_id, 'project_tag');
        }
        return get_post_type_archive_link('ctrl_projects');
    }
endif;

function control_agency_related_query_args() {
    global $controlAgency;
    if ( empty($controlAgency->post_type__taxonomies[get_post_type()])) return false;

    $tax_query = [];
    foreach ($controlAgency->post_type__taxonomies[get_post_type()] as $taxonomy) {       
        $term_ids = wp_get_post_terms(get_the_ID(), $taxonomy, array('fields' => 'ids'));
        if (empty($term_ids) || is_wp_error($term_ids)) continue;
        $tax_query[] = [
            'taxonomy' => $taxonomy,
            'field' => 'term_id',
            'terms' => $term_ids,
            'operator' => 'IN',
        ];
    }


    if (count($tax_query) > 1) {
        $tax_query['relation'] = 'OR';
    }

    $query_args = [
        'post_type' => get_post_type(),
        'post__not_in' => [get_the_ID()],
        'posts_per_page' => 5,
        'tax_query' => $tax_query
    ];

    return $query_args;
}


function control_agency_banner_css_style($attachment_id, $size = 'full') {
    if (empty($attachment_id) && has_post_thumbnail()) {
        $attachment_id = get_post_thumbnail_id();
    }

    if (empty($attachment_id)) return;

    $image = wp_get_attachment_image_src($attachment_id, $size, false);
    if (empty($image[0]) || is_wp_error($image)) return;

    return ' style="background-image: url(' . $image[0] . ')"';
}


function control_agency_get_attachment_url($attachment_ids = NULL, $size = 'full', $default = NULL) {
    if (empty($attachment_ids) || is_wp_error($attachment_ids)) {
        return $default;
    }

    if(!empty($attachment_ids['url'])){
        $attachment_url =  $attachment_ids['url'];
    }else{
        if (!is_array($attachment_ids)) {
            $attachment_ids = explode(',', $attachment_ids);
        }
    
        if (empty($attachment_ids)) {
            return $default;
        }
    
        $attachment_id = end($attachment_ids);
        $attachment_url =  wp_get_attachment_image_url($attachment_id, $size);
    }
    

    if (empty($attachment_url) || is_wp_error($attachment_url)) {
        return $default;
    }

    return $attachment_url;
}

function control_agency_get_attachment_urls($attachment_ids = NULL, $size = 'full', $default = []) {
    if (empty($attachment_ids)) return;
    if (is_string($attachment_ids)) {
        $attachment_ids = explode(',', $attachment_ids);
    }
    $image_urls = $default;
    foreach ($attachment_ids as $key => $attachment_id) {
        $default_image = !empty($default[$key]) ? $default[$key] : '';
        $image_urls[$key] = control_agency_get_attachment_url($attachment_id, $size, $default_image);
    }

    return $image_urls;
}

function control_agency_query_field($post_type, $field_id = NULL) {
    $args = get_post_type_object($post_type);
    $fields = [
        [
            'id' => "post_type",
            'type' => 'hidden',
            'std' => $post_type,
            'attributes' => ['value' => $post_type, 'id' => $field_id . '_post_type'],
        ],
        [
            'id' => "posts_per_page",
            'name' => esc_attr__('Posts per Page', 'control-agency'),
            'placeholder' => esc_attr__('-- Posts per Page --', 'control-agency'),
            'type' => 'number',
            'min' => -1,
            'max' => 100,
            'step' => 1,
            'size' => 10,
            'desc' => sprintf(esc_attr__('Total number of %s to retrieve. Accepts -1 for all. Default %s.', 'control-agency'), '<code>' . $args->labels->singular_name . '</code>', '<code>' . get_option('posts_per_page') . '</code>')
        ],

        [
            'id' => 'order',
            'name' => esc_attr__('Order', 'control-agency'),
            'type' => 'select',
            'placeholder' => '-- Order --',
            'options' => [
                'ASC' => esc_attr__('ASC', 'control-agency'),
                'DESC' => esc_attr__('DESC', 'control-agency'),
            ],
            'inline' => true,
        ],
        [
            'id' => 'orderby',
            'name' => esc_attr__('Order By', 'control-agency'),
            'type' => 'select',
            'multiple' => false,
            'placeholder' => '-- Orderby --',
            'options' => [
                'none' => esc_attr__('No order', 'control-agency'),
                'ID' => esc_attr__('Order by post id. Note the capitalization', 'control-agency'),
                'author' => esc_attr__('Order by author', 'control-agency'),
                'title' => esc_attr__('Order by title', 'control-agency'),
                'name' => esc_attr__('Order by post name (post slug)', 'control-agency'),
                'date' => esc_attr__('Order by date', 'control-agency'),
                'modified' => esc_attr__('Order by last modified date', 'control-agency'),
                'parent' => esc_attr__('Order by post/page parent id', 'control-agency'),
                'rand' => esc_attr__('Random order', 'control-agency'),
                'menu_order' => esc_attr__('Menu Order', 'control-agency'),
            ],

        ],
        [
            'id' => 'post__in',
            'name' => sprintf(esc_attr__('Posts in', 'control-agency'), $args->labels->singular_name),
            'type' => 'post',
            'field_type' => 'select_advanced',
            'placeholder' => sprintf('-- %s includes --', $args->labels->singular_name),
            'post_type' => $post_type,
            'multiple' => true,
            'select_all_none' => false,
            'desc'  => sprintf('Specify %s to retrieve', $args->labels->singular_name),
            'options' => [
                '' => sprintf('-- %s includes --', $args->labels->singular_name),
            ],
            'attributes' => ['id' => $field_id . '_post__in'],
        ],
        [
            'id' => 'post__not_in',
            'name' => esc_attr__('Posts not in', 'control-agency'),
            'type' => 'post',
            'field_type' => 'select_advanced',
            'placeholder' => sprintf('-- %s excludes --', $args->labels->singular_name),
            'post_type' => $post_type,
            'multiple' => true,
            'select_all_none' => false,
            'desc'  => sprintf('Specify %s NOT to retrieve', $args->labels->singular_name),
            'attributes' => ['id' => $field_id . '_post__not_in'],
        ],

    ];



    return $fields;
}

function control_agency_post_type_custom_loop($args = []) {
}



add_action('init', 'control_agency_load_mb_field_type');
function control_agency_load_mb_field_type() {
    if (class_exists('RWMB_Field')) :
        require __DIR__ . '/field/button.php';
        require __DIR__ . '/field/query.php';
    endif;
}

function control_agency_post_type_query_options($post_type, $options = []) {   
    $queries = control_agency_post_type_option('custom_query', [], $post_type);
   
    if (empty($queries)) return $options;

    foreach ($queries as $key => $value) {
        $options[$value['title']] = $value['title'];
    }
    return $options;
}

function control_agency_get_query_args($query_key, $post_type = 'post') {    
    $queries = control_agency_post_type_option('custom_query', [], $post_type);

    foreach ($queries as $key => $value) {
        if($value['title'] == $query_key){
            $query = $value['query'];
            break;
        }
    }
    
    if(is_singular() && (get_post_type() == $post_type)){
        if(!empty($query['post__not_in'])){
            $query['post__not_in'][] = get_the_ID();
        }else{
            $query['post__not_in'] =[ get_the_ID()];
        }
        $query['orderby'] = !empty($query['orderby'])? $query['orderby'] : 'rand';
    }

    return $query;
}

function control_agency_get_btn($args, $before = '', $after = '') {
    if (is_string(reset($args))) {
        $args = [$args];
    }

    ob_start();
    foreach ($args as $btn_args) {
        control_agency_render_template('components/button.php', $btn_args);
    }

    $buttons = ob_get_clean();
    return $before . $buttons . $after;
}



