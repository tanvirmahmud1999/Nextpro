<?php
if(!function_exists('control_agency_get_job_blocks_options')){
    function control_agency_get_job_blocks_options(){
        return apply_filters('control_agency_get_job_blocks_options', []);
    }
}

if(!function_exists('control_agency_get_job_blocks_std')){
    function control_agency_get_job_blocks_std(){
        return apply_filters('control_agency_get_job_blocks_std', [
            [
                'name' => 'Job Banner',
                'template' => 'banner-single',
            ],            
            [
                'name' => 'Job Content',
                'template' => 'editor-content',
            ],
            [
                'name' => 'Key responsibilities',
                'template' => 'area-of-expertise',
            ],
            [
                'name' => 'Related Jobs',
                'template' => 'jobs-template',
            ]            
        ]);
    }
}

function control_agency_job_banner_single_std($defaults = []){
    $args = [
        'template' => 'job/single/banner.php',
        'title' => '[job_title] -->',
        'subtitle' => esc_attr__('Get Right Solution For Business', 'control-agency'),
        'desc' => '[job_excerpt]'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_job_banner_single_std', $args);
}

function control_agency_job_editor_content_std($defaults = []){
    $args = [
        'template' => 'job/single/content.php',
        'title' => 'Hello, Applicants!'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_job_editor_content_std', $args);
}

function control_agency_job_area_of_expertise_std($defaults = []){
    $args = [
        'title' => 'Key areas {of} Responsibilities',
        'subtitle' => 'As designers, we believe that brands and products impact the world around us more than any other form of art. We shape culture, influence society, and drive the economy.',
        'button_text' => 'Apply Now',
        'footer_text' => 'We are looking for you',
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_job_area_of_expertise_std', $args);
}