<?php
if(!function_exists('control_agency_get_service_blocks_options')){
    function control_agency_get_service_blocks_options(){
        return apply_filters('control_agency_get_service_blocks_options', []);
    }
}

if(!function_exists('control_agency_get_service_blocks_std')){
    function control_agency_get_service_blocks_std(){
        return apply_filters('control_agency_get_service_blocks_std', [
            [
                'name' => 'Service Banner',
                'template' => 'banner-single',
            ],
            [
                'name' => 'Service Cloud',
                'template' => 'tags',
            ],
            [
                'name' => 'Service Content',
                'template' => 'editor-content',
            ],
            [
                'name' => 'What we Offers',
                'template' => 'what-we-offers',
            ], 
            [
                'name' => 'Work Process',
                'template' => 'how-can-grow',
            ],
            
            [
                'name' => 'FAQs',
                'template' => 'faqs',
            ],
            [
                'name' => 'Recent Works',
                'template' => 'projects-template',
            ], 
            [
                'name' => 'Client Reviews',
                'template' => 'testimonials',
            ],
                       
        ]);
    }
}


function control_agency_service_banner_single_std($defaults = []){
    $args = [
        'template' => 'service/single/banner.php',
        'title' => '[service_title]',
        'subtitle' => esc_attr__('Get Right Solution For Business', 'control-agency'),
        'desc' => '[service_excerpt]'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_service_banner_single_std', $args);
}

function control_agency_service_editor_content_std($defaults = []){
    $args = [
        'template' => 'service/single/content.php'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_service_editor_content_std', $args);
}

function control_agency_service_what_we_offers_std($defaults = []){
    $args = [
        'title' => 'Our services solve any business problem',
        'subtitle' => 'Discover powerful features to boost your productivity. You are always welcome to visit our little den.',
        'button_text' => 'Geta a Quote'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_service_what_we_offers_std', $args);
}

function control_agency_service_projects_template_std($defaults = []){
    $args = [
        'template' => 'project/template-gallery.php',
        'title' => 'Recent {Work}',
        'subtitle' => 'As designers, we believe that brands and products impact the world around us more than any other form of art. We shape culture, influence society, and drive the economy.',
        'query' => 'Recent Projects'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_service_projects_template_std', $args);
}


