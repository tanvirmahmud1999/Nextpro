<?php
/**
 * Retrieves an array of the class names for the item element.
 *
 * @global WP_Query $wp_query WordPress Query object.
 *
 * @param string|string[] $class Space-separated string or array of class names to add to the class list.
 * @return string[] Array of class names.
 */
function control_agency_get_item_class( $class = '' ) {
    global $control_agency_isotope, $control_agency_counter;
	$classes = array( 'item-portfolio');
    
    $bg_classes = ['bg-10', 'bg-11', 'bg-12']; 
    $classes[] = $bg_classes[$control_agency_counter%3];  

    if($control_agency_isotope){             
        $classes[] = 'filter-item';
        $classes[] = control_agency_get_terms(['slug' => true, 'separator' => ' '], false);
    }
    
    if($control_agency_counter%2 == 1){
        $classes[] = 'flex-row-reverse';
    }
	
	
	if ( ! empty( $class ) ) {
		if ( ! is_array( $class ) ) {
			$class = preg_split( '#\s+#', $class );
		}
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );

	/**
	 * Filters the list of CSS footer class names for the current post or page.
	 *
	 * @param string[] $classes An array of footer class names.
	 * @param string[] $class   An array of additional class names added to the footer.
	 */
	$classes = apply_filters( 'control_agency_item_class', $classes, $class );

	return array_unique( $classes );
}


/**
 * Displays the class names for the item element.
 *
 * @param string|string[] $class Space-separated string or array of class names to add to the class list.
 */
function control_agency_item_class( $class = '' ) {
	// Separates class names with a single space, collates class names for footer element.
	echo 'class="' . esc_attr( implode( ' ', control_agency_get_item_class( $class ) ) ) . '"';
}


function control_agency_featured_template(){
    if(!is_post_type_archive()) return;
    $query_args = [
        'post_type' => 'controlproject',
        'meta_key' => 'featured',
        'meta_value' => true
        
    ];

    // The Query.
    $the_query = new WP_Query( $query_args );
    // The Loop.
    if ( $the_query->have_posts() ) {
        ob_start();
        while ( $the_query->have_posts() ) {
            $the_query->the_post();                          
            control_agency_template_part('projects/loop/content-slide');
           
        }
    } 

    $content = ob_get_clean();
    // Restore original Post Data.
    wp_reset_postdata();
    if(empty($content)) return;
    $args = [
        'content' => $content
    ];
   
    control_agency_locate_template('projects/loop/featured-projects.php', $args);
}


function control_agency_testimonial_template(){
    $testimonial = get_post_meta(get_the_ID(), 'testimonial', true);
    if(!empty($testimonial) || !empty($testimonial['content'])) {
        $args = [
            'testimonial_content' => $testimonial['content']
        ];
        if(!empty($testimonial['image'][0]) ){
            $args['testimonial_image'] = wp_get_attachment_image_url( $testimonial['image'][0], 'thumbnail');
        }
        $args['website'] = !empty($testimonial['website'])? $testimonial['website'] : '#';
        $args['name'] = !empty($testimonial['name'])? $testimonial['name'] : '';
        $args['designation'] = !empty($testimonial['designation'])? $testimonial['designation'] : '';
        control_agency_locate_template('projects/loop/testimonial.php', $args);
    }
}

if(!function_exists('control_agency_get_project_blocks_options')){
    function control_agency_get_project_blocks_options(){
        return apply_filters('control_agency_get_project_blocks_options', []);
    }
}

if(!function_exists('control_agency_get_project_blocks_std')){
    function control_agency_get_project_blocks_std(){
        return apply_filters('control_agency_get_project_blocks_std', [
            [
                'name' => 'Project Banner',
                'template' => 'banner-single',
            ],
            [
                'name' => 'Project Content',
                'template' => 'editor-content',
            ],
            [
                'name' => 'Related Projects',
                'template' => 'projects-template',
            ]            
        ]);
    }
}

function control_agency_project_banner_single_std($defaults = []){
    $args = [
        'template' => 'project/single/banner.php',
        'title' => '[project_title]',
        'subtitle' => esc_attr__('Get Right Solution For Business', 'control-agency'),
        'desc' => '[project_excerpt]'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_project_banner_single_std', $args);
}

function control_agency_project_editor_content_std($defaults = []){
    $args = [
        'template' => 'project/single/content.php'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_project_editor_content_std', $args);
}

function control_agency_project_projects_template_std($defaults = []){
    $args = [
        'template' => 'project/single/related.php',
        'title' => 'Related Work',
        'subtitle' => 'Our More Projects',
        'query' => ''
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_project_projects_template_std', $args);
}