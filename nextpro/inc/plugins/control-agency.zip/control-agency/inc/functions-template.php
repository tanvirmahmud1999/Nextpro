<?php
if(!function_exists('control_agency_locate_template')):
/**
 * Retrieve the name of the highest priority template file that exists.
 *
 * Searches in the stylesheet_directory before TEMPLATEPATH and CTRL_AGENCY_TEMPLATEPATH
 * so that themes which inherit from a parent theme can just overload one file.
 *
 * @param 	string|array 	$template_names Template file(s) to search for, in order.
 * @param 	array        	$args           Optional. Additional arguments passed to the template.
 *                                     		Default empty array.
 * @return 	string The template filename if one is located.
 */
function control_agency_locate_template( $template_name, $args = array() ) {
    $located = '';
    $templates_dir = apply_filters( 'control_projects/template_directory', '/control-agency/' );
    $supported_active_theme_dir = CTRL_AGENCY_TEMPLATEPATH.wp_get_theme()->get('TextDomain').'/';
    
    if ( file_exists( CTRL_AGENCY_TEMPLATEPATH . $template_name ) ) {
        $located = CTRL_AGENCY_TEMPLATEPATH . $template_name;
    }

    $located = apply_filters('control_agency_locate_template', $located, $template_name);
    $located = apply_filters("control_projects/template/{$template_name}", $located, $template_name);
    
    if ( file_exists( get_stylesheet_directory() . $templates_dir . $template_name ) ) {
        $located = get_stylesheet_directory() . $templates_dir . $template_name;
    } elseif ( file_exists( get_template_directory() . $templates_dir . $template_name ) ) {
        $located = get_template_directory() . $templates_dir . $template_name;
    } elseif(file_exists( $supported_active_theme_dir . $template_name )){
        $located = $supported_active_theme_dir . $template_name;
    } 


    if ( '' !== $located ) {
        if(!is_array($args)) $args = (array)$args;
        extract($args);
        include( $located );
    }
}
endif;
    
if(!function_exists('control_agency_template')):
/**
 * Retrieve the name of the highest priority template file that exists.
 *
 * Searches in the STYLESHEETPATH before TEMPLATEPATH and CTRL_AGENCY_TEMPLATEPATH
 * so that themes which inherit from a parent theme can just overload one file.
 *

    *
    * @param 	string|array $template_names 	Template file(s) to search for, in order.
    * @param 	bool         $load           	If true the template file will be loaded if it is found.
    * @param 	bool         $require_once   	Whether to require_once or require. Has no effect if `$load` is false.
    *                                     		Default true.
    * @param 	array        $args          	Optional. Additional arguments passed to the template.
    *                                     		Default empty array.
    * @return 	string 	The template filename if one is located.
    */
function control_agency_template( $template_names, $load = false, $require_once = true, $args = array() ) {
    
    $located = '';
    $templates_dir = apply_filters( 'control_projects/template_directory', '/control-agency/' );
    $supported_active_theme_dir = CTRL_AGENCY_TEMPLATEPATH.wp_get_theme()->get('TextDomain').'/';
    foreach ( (array) $template_names as $template_name ) {
        if ( ! $template_name ) {
            continue;
        }
        
        if ( file_exists( CTRL_AGENCY_TEMPLATEPATH . $template_name ) ) {
            $located = CTRL_AGENCY_TEMPLATEPATH . $template_name;
        }

        $located = apply_filters('control_agency_template', $located, $template_name);		
        $located = apply_filters("control_projects/template/{$template_name}", $located, $template_name);

        if ( file_exists( get_stylesheet_directory() . $templates_dir . $template_name ) ) {
            $located = get_stylesheet_directory() . $templates_dir . $template_name;
        } elseif ( file_exists( get_template_directory() . $templates_dir . $template_name ) ) {
            $located = get_template_directory() . $templates_dir . $template_name;
        }elseif(file_exists( $supported_active_theme_dir . $template_name )){
            $located = $supported_active_theme_dir . $template_name;			
        }

        
        if('' !== $located){
            break;
        }
    }

    if ( $load && '' !== $located ) {
        load_template( $located, $require_once, $args );
    }

    

    return $located;
}
endif;
    
if(!function_exists('control_agency_template_part')):
/**
 * Loads a template part into a template.
 *
 * Provides a simple mechanism for child themes to overload reusable sections of code
 * in the theme.
 *
 * Includes the named template part for a theme or if a name is specified then a
 * specialised part will be included. If the theme contains no {slug}.php file
 * then no template will be included.
 *
 * The template is included using require, not require_once, so you may include the
 * same template part multiple times.
 *
 * For the $name parameter, if the file is called "{slug}-special.php" then specify
 * "special".
 *
 * @param 	string 	$slug 	The slug name for the generic template.
 * @param 	string 	$name 	The name of the specialised template.
 * @param 	array  	$args 	Optional. Additional arguments passed to the template.
 *                     		Default empty array.
 * @return 	void|false 		Void on success, false if the template does not exist.
 */
function control_agency_template_part( $slug, $name = null, $args = array() ) {
    /**
     * Fires before the specified template part file is loaded.
     *
     * The dynamic portion of the hook name, `$slug`, refers to the slug name
     * for the generic template part.
     *
     * @param string      $slug The slug name for the generic template.
     * @param string|null $name The name of the specialized template.
     * @param array       $args Additional arguments passed to the template.
     */
    do_action( "get_template_part_{$slug}", $slug, $name, $args );

    $templates = array();
    $name      = (string) $name;
    if ( '' !== $name ) {        
        $templates[] = "{$name}/{$slug}.php";
        $templates[] = "{$slug}-{$name}.php";
    }

    $templates[] = "{$slug}.php";

    /**
     * Fires before an attempt is made to locate and load a template part.
     *
     * @param string   $slug      The slug name for the generic template.
     * @param string   $name      The name of the specialized template.
     * @param string[] $templates Array of template files to search for, in order.
     * @param array    $args      Additional arguments passed to the template.
     */
    do_action( 'get_template_part', $slug, $name, $templates, $args );
    
    if ( ! control_agency_template( $templates, true, false, $args ) ) {
        return false;
    }
}
endif;

function control_agency_render_template_part($slug, $name = null, $args = array()){
    /**
     * Fires before the specified template part file is loaded.
     *
     * The dynamic portion of the hook name, `$slug`, refers to the slug name
     * for the generic template part.
     *
     * @param string      $slug The slug name for the generic template.
     * @param string|null $name The name of the specialized template.
     * @param array       $args Additional arguments passed to the template.
     */
    do_action( "get_template_part_{$slug}", $slug, $name, $args );

    $templates = array();
    $name      = (string) $name;
    if ( '' !== $name ) {        
        $templates[] = "{$name}/{$slug}.php";
        $templates[] = "{$slug}-{$name}.php";
    }

    $templates[] = "{$slug}.php";

    /**
     * Fires before an attempt is made to locate and load a template part.
     *
     * @param string   $slug      The slug name for the generic template.
     * @param string   $name      The name of the specialized template.
     * @param string[] $templates Array of template files to search for, in order.
     * @param array    $args      Additional arguments passed to the template.
     */
    do_action( 'get_template_part', $slug, $name, $templates, $args );
    

    $located = control_agency_template($templates);
    
    if($located){
        $function_name = 'control_agency_template_'.str_replace(['-', '.php'], ['_'], basename($located)).'_args';
        if(function_exists($function_name)){
            $defaults = call_user_func($function_name);
            $atts = wp_parse_args($args, $defaults);
        }
        extract($atts);
        include $located;
        return;
    }else{
        if(current_user_can('customize')){
            printf('<div class="container"><div class="alert alert-danger">'.esc_attr__('%s template not found!!!', 'control-agency').'</div></div>', '<code>'.$template_file.'</code>');
        }
        
    }
}

function control_agency_render_template($template_file, $args= []){
    $located = control_agency_template($template_file);
    
    if($located){
        $function_name = 'control_agency_template_'.str_replace(['-', '.php'], ['_'], basename($template_file)).'_args';
        if(function_exists($function_name)){
            $defaults = call_user_func($function_name);
            $args = wp_parse_args($args, $defaults);
        }
        extract($args);
        include $located;
        return;
    }else{
        if(current_user_can('customize')){
            printf('<div class="container"><div class="alert alert-danger">'.esc_attr__('%s template not found!!!', 'control-agency').'</div></div>', '<code>'.$template_file.'</code>');
        }
        
    }
}

function control_agency_render_block_template($attributes, $is_preview = false, $post_id = null){
    // Fields data.
    if ( empty( $attributes['data'] ) ) {
        return;
    }	
    
    if(!empty($attributes['data']['template'])){
        $template_file = $attributes['data']['template'];
    }elseif(!empty($attributes['data']['template_file'])){
        $template_file = $attributes['data']['template_file'];
    }else{
        $template_file = 'blocks/'.str_replace('control-agency-', '', $attributes['name']) .'.php'; 
    }
    
    control_agency_render_template($template_file, $attributes['data']);	
        
}


function control_agency_located_file($template_name){
    $located = '';
    $templates_dir = apply_filters( 'control_projects/template_directory', '/control-agency/' );
    $supported_active_theme_dir = CTRL_AGENCY_TEMPLATEPATH.wp_get_theme()->get('TextDomain').'/';
    
    if ( file_exists( CTRL_AGENCY_TEMPLATEPATH . $template_name ) ) {
        $located = CTRL_AGENCY_TEMPLATEPATH . $template_name;
    }

    $located = apply_filters('control_agency_locate_template', $located, $template_name);
    $located = apply_filters("control_projects/template/{$template_name}", $located, $template_name);
    
    if ( file_exists( get_stylesheet_directory() . $templates_dir . $template_name ) ) {
        $located = get_stylesheet_directory() . $templates_dir . $template_name;
    } elseif ( file_exists( get_template_directory() . $templates_dir . $template_name ) ) {
        $located = get_template_directory() . $templates_dir . $template_name;
    } elseif(file_exists( $supported_active_theme_dir . $template_name )){
        $located = $supported_active_theme_dir . $template_name;
    } 
    return $located;
}

function control_agency_config($id = NULL){
    $located = control_agency_located_file('config.php');
    

    if(empty($located)) return;
    $data = include $located;

    if(!empty($id) && !empty($data[$id])){
        return $data[$id];
    }else{
        return false;
    }    
    
}

if(!function_exists('control_agency_post_type_content')):
function control_agency_post_type_content(){
    global $controlAgency;
    $archive_page_id = !empty($controlAgency->archive_pages[get_post_type()])? $controlAgency->archive_pages[get_post_type()] : false;
    $callback_functions = [];
    $templates = control_agency_post_type_option('archive_template');   
    if($archive_page_id && !empty($templates)){
        foreach ($templates as $key => $value) {
            $key = $value['template'];
            $callback_function =  ($key == 'content-page')? 'control_agency_post_type_page_content' : 'control_agency_post_type_loop_content';
            $callback_functions[$key] = $callback_function;
        }
    }
    
    if(empty($callback_functions) || is_paged() || is_singular()){
        $callback_functions = [
            'content-archive' => 'control_agency_post_type_loop_content'
        ];
    }
    $GLOBALS['control_agency_post_type_content'] =  $callback_functions;  

    foreach ($callback_functions as $function_name) {
        call_user_func($function_name);
    }
    
}
endif;

if(!function_exists('control_agency_post_type_page_content')):
    function control_agency_post_type_page_content(){
        if( !is_post_type_archive() ) return;

        global $controlAgency, $control_agency_options;
        $archive_page_id = !empty($controlAgency->archive_pages[get_post_type()])? $controlAgency->archive_pages[get_post_type()] : false;
        if( !$archive_page_id) return;

        $page = get_post( $archive_page_id, OBJECT, 'display' );
        $args = array_merge($control_agency_options, [
            'page_id' => $archive_page_id,
            'page' => $page,
            'page_content' => apply_filters('the_content', $page->post_content),
        ]);
        
        control_agency_render_template('content-page.php', $args);  
        
    }
endif;

if(!function_exists('control_agency_post_type_loop_content')):
    function control_agency_post_type_loop_content(){
        global $control_agency_options;
        if(is_singular()){                
            control_agency_render_template('content-single.php', $control_agency_options);            
        }else{
            control_agency_render_template('content-archive.php', $control_agency_options);               
        }
    }
endif;

if(!function_exists('control_agency_post_type_loop')):
    function control_agency_post_type_loop(){
       
        if ( have_posts() ):
    
            do_action('control_agency_archive_loop_start');	
            // Load posts loop.
            while ( have_posts() ) {
                the_post();
                do_action('control_agency_archive_loop_content');
            }	
            
            do_action('control_agency_archive_loop_end');
        
        else:
        
            // If no content, include the "No posts found" template.
            do_action('control_agency_loop_no_posts');
        
        endif;              
        
    }
endif;

function control_agency_file_uri($template_name){
    $located = $uri = '';
    $templates_dir = apply_filters( 'control_projects/template_directory', '/control-agency/' );
    $supported_active_theme_dir = CTRL_AGENCY_TEMPLATEPATH.wp_get_theme()->get('TextDomain').'/';
    
    if ( file_exists( CTRL_AGENCY_TEMPLATEPATH . $template_name ) ) {
        $located = CTRL_AGENCY_TEMPLATEPATH . $template_name;
        $uri = trailingslashit(CTRL_AGENCY_TEMPLATEPATH_URI).$template_name;
    }

    $located = apply_filters('control_agency_locate_template', $located, $template_name);
    $located = apply_filters("control_projects/template/{$template_name}", $located, $template_name);
    
    if ( file_exists( get_stylesheet_directory() . $templates_dir . $template_name ) ) {
        $located = get_stylesheet_directory() . $templates_dir . $template_name;
        $uri = get_theme_file_uri($templates_dir . $template_name);
    } elseif ( file_exists( get_template_directory() . $templates_dir . $template_name ) ) {
        $located = get_template_directory() . $templates_dir . $template_name;
        $uri = get_theme_file_uri($templates_dir . $template_name);
    } elseif(file_exists( $supported_active_theme_dir . $template_name )){
        $located = $supported_active_theme_dir . $template_name;
        $uri = get_theme_file_uri($templates_dir . $template_name);
    } 
    return $uri;
}


function control_agency_enqueue_style($relative_file_uri, $dep = [], $ver=""){
    $file_uri = control_agency_file_uri($relative_file_uri);
    if(empty($file_uri)) return;

    if(empty($ver)){
        $ver = CTRL_AGENCY_VER;
        $ver .= WP_DEBUG? '-'.time() : '';
    }

    if(empty($dep)){
        wp_enqueue_style("control-agency-common", control_agency_file_uri('assets/css/common.css'), [], $ver);
        $dep[] = "control-agency-common";
    }


    $handle = str_replace(['_', ' '], '-', basename($relative_file_uri));
    $handle = str_replace('.css', '', $handle);
    wp_enqueue_style("control-agency-{$handle}", $file_uri, $dep, $ver);
}
