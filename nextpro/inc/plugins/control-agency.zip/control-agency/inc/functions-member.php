<?php
if(!function_exists('control_agency_get_member_blocks_options')){
    function control_agency_get_member_blocks_options(){
        return apply_filters('control_agency_get_member_blocks_options', []);
    }
}

if(!function_exists('control_agency_get_member_blocks_std')){
    function control_agency_get_member_blocks_std(){
        return apply_filters('control_agency_get_member_blocks_std', [
            [
                'name' => 'Banner',
                'template' => 'banner-single',
            ],
            [
                'name' => 'Area of expertise',
                'template' => 'area-of-expertise',
            ],
            [
                'name' => 'Content',
                'template' => 'editor-content',
            ],
            [
                'name' => 'Recent Works',
                'template' => 'projects-template',
            ]            
        ]);
    }
}

function control_agency_member_banner_single_std($defaults = []){
    $args = [
        'template' => 'member/single/banner.php',
        'title' => 'I am [member_title] -->',
        'subtitle' => esc_attr__('Get Right Solution For Business', 'control-agency'),
        'desc' => '[member_excerpt]'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_member_banner_single_std', $args);
}

function control_agency_member_editor_content_std($defaults = []){
    $args = [
        'template' => 'member/single/content.php',
        'title' => 'Hello, friend!'
    ];
    $args = wp_parse_args($args, $defaults);
    return apply_filters('control_agency_member_editor_content_std', $args);
}