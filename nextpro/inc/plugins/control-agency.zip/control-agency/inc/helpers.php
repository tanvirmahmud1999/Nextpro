<?php
if (!function_exists('control_agency_parse_text')) {
    /**
     * Replaces placeholders in the text with specified HTML tags and optional hyperlinks.
     *
     * @param string $text The input text containing placeholders in the format `{placeholder}`.
     * @param array|string $args Arguments to customize the output:
     *                           - 'tag' (string): HTML tag to wrap around the placeholder content. Default 'span'.
     *                           - 'tagclass' (string): CSS class for the HTML tag. Default empty string.
     *                           - 'before' (string): Text to insert before the HTML tag. Default empty string.
     *                           - 'after' (string): Text to insert after the HTML tag. Default empty string.
     *                           - 'href' (string): URL to wrap the HTML tag in an anchor (`<a>`) tag. Default empty string.
     *                           - 'symbols_to_icon' (bool): Currently not used. Default false.
     * @return string Processed text with placeholders replaced by the specified HTML tags.
     */
    function control_agency_parse_text($text, $args = array()) {
        if (empty($text)) return $text;

        if (is_array($args)) {
            extract(shortcode_atts(array(
                'tag' => 'span',
                'tagclass' => '',
                'class' => '',
                'before' => '',
                'after' => '',
                'href' => '',
                'atts' => '',
                'symbols_to_icon' => false
            ), $args));
        } else {
            extract(shortcode_atts(array(
                'tag' => $args,
                'tagclass' => '',
                'class' => '',
                'before' => '',
                'after' => '',
                'href' => '',
                'atts' => '',
                'symbols_to_icon' => false
            ), $args));
        }

        preg_match_all("/\{([^\}]*)\}/", $text, $matches);
        $tagclass = !empty($class)? trim($class) : trim($tagclass);
        $tagclass = !empty($tagclass) ? " class='{$tagclass}'" : '';
        $attributes = '';
        if(!empty($atts)){            
            $attsArr = explode('|', $atts);
            foreach ($attsArr as $attribute) {
                $attributeArr = explode(':', $attribute);
                if(count($attributeArr) != 2 ) continue;
                $attributes .= " {$attributeArr[0]}='{$attributeArr[1]}'";
            }
        }


        if (!empty($matches)) {
            foreach ($matches[1] as $value) {
                $find = "{{$value}}";
                if (!empty($href)) {
                    $replace = "{$before}<a href='{$href}'><{$tag}{$tagclass}{$attributes}>{$value}</{$tag}></a>{$after}";
                } else {
                    $replace = "{$before}<{$tag}{$tagclass}{$attributes}>{$value}</{$tag}>{$after}";
                }
                $text = str_replace($find, $replace, $text);
            }
        }

        return $text;
    }
}

if (!function_exists('control_agency_array_search_by_key_value')) {
    /**
     * Recursively searches an array for sub-arrays containing a specific key-value pair.
     *
     * @param array $array The array to search.
     * @param string $key The key to search for.
     * @param mixed $value The value to match against the key.
     * @return array An array of sub-arrays that contain the specified key-value pair.
     */
    function control_agency_array_search_by_key_value($array, $key, $value) {
        $results = array();
    
        if (is_array($array)) {
            if (isset($array[$key]) && $array[$key] == $value) {
                $results[] = $array;
            }
    
            foreach ($array as $subarray) {
                $results = array_merge($results, control_agency_array_search_by_key_value($subarray, $key, $value));
            }
        }
    
        return $results;
    }
}

if (!function_exists('control_agency_get_title')) {
    /**
     * Retrieves the title for the current post or archive page, with custom handling for archive pages.
     *
     * @return string The title of the current post or archive page.
     */
    function control_agency_get_title($before="", $after="") {
        $title = get_the_title();

        if (is_post_type_archive()) {
            $title = get_the_archive_title();
            global $controlAgency;
            $post_type = get_post_type();
            $custom_title = control_agency_post_type_option('archive_page_title');
            if(!empty($custom_title)){
                $title = $custom_title;
            }

            if (!empty($controlAgency->archive_pages[$post_type])) {
                $title = get_the_title($controlAgency->archive_pages[$post_type]);
            }
        }

        return $before.$title.$after;
    }
}

function control_agency_get_archive_title($before="", $after="", $echo = true){
    if($echo){
        echo control_agency_get_title($before, $after);
    }else{
        return control_agency_get_title($before, $after);
    }
}

function control_agency_get_archive_description($before="", $after="", $echo = true){
    $output = get_the_archive_description();
    global $controlAgency;
    $post_type = get_post_type();
    $custom_output = control_agency_post_type_option('archive_page_desc');
    
    if (!empty($controlAgency->archive_pages[$post_type])) {
        $custom_output = get_post_meta($controlAgency->archive_pages[$post_type], 'subtitle', true);
    }

    if(!empty($custom_output)){
        $output = $custom_output;
    }

    if($echo){
        echo $before.$output.$after;
    }else{
        return $before.$output.$after;
    }
}

/**
 * Gets the SVG code for a given icon.
 *
 * @param 	string 	$group The icon group.
 * @param 	string 	$icon  The icon.
 * @param 	int    	$size  The icon size in pixels.
 * @return 	string
 */
function control_agency_get_icon_svg( $group, $icon, $size = 24 ) {
	return ControlAgency\SVG_Icons::get_svg( $group, $icon, $size );
}