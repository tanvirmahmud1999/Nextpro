<?php
return [
    [
        'placeholder'        => esc_attr__('Button Text', 'nextpro'),
        'id'          => 'text',
        'type'        => 'text',
        'std'         => 'Purchase NextPro',
    ],
    [
        'placeholder'        => esc_attr__('Button URL', 'nextpro'),
        'id'          => 'url',
        'type'        => 'text',
        'std'         => '#',
    ],
    [
        'placeholder'        => esc_attr__('Target', 'nextpro'),
        'id'          => 'target',
        'type'        => 'select',
        'options'         => [
            '' => 'Open in same window',
            '_blank' => 'Open in new window',
        ],
    ],

    [
        'placeholder'        => esc_attr__('Button class', 'nextpro'),
        'id'          => 'class',
        'type'        => 'text',
        'desc'         => 'You can use extra class if you like to add additional styling or any other button style',
    ],
    [
        'placeholder'        => esc_attr__('Attributes', 'nextpro'),
        'id'          => 'attributes',
        'type'        => 'key_value',
        'add_button'         => '+',
    ],
];
