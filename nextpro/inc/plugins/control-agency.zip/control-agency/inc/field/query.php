<?php
class RWMB_Query_Field extends RWMB_Field {
    public static function admin_enqueue_scripts() {
        // RWMB_Select_Advanced_Field::admin_enqueue_scripts();
    }
   
    public static function html( $meta, $field ) {
        
        if(empty($field['post_type'])) return;

        $meta = wp_parse_args($meta, [
            'post_type' => 'post',
            'posts_per_page' => get_option('posts_per_page'),
            'order' => '',
            'order_by' => '',
            'post__in' => [],
            'post__not_in' => [],
            'tax_query' => [],
            'meta_query' => [],
        ]);

        $output = '<div class="query-field">';
       
         // post_type.
        $field_id = sanitize_title($field['field_name']);
		$group = RWMB_Group_Field::normalize( [
			'type'        => 'group',
			'id'          => $field_id,
			'field_name'  => $field['field_name'],
            'default' => true,
            'clone' => false,
            'sort_clone' => false,
            'std' => $field['std'],
			'fields' => control_agency_query_field($field['post_type'], $field_id)
		] );
		$output    .= RWMB_Group_Field::html( $meta, $group );        

        $output .= '</div>';


        return $output;
    }

    public static function get_post_types(){
        global $controlAgency;
        $post_types = [
            'post' => 'Post'
        ];
        foreach ($controlAgency->post_types as $key => $post_type) {
            $args = controlAgency\Helper::include_admin_file("post-types/{$key}.php");
            $post_types[$post_type] = $args['label'];
        }
        return $post_types;
    }
    
}
