<?php
class RWMB_Btn_Field extends RWMB_Field {
    public static function admin_enqueue_scripts() {
        // RWMB_Select_Advanced_Field::admin_enqueue_scripts();
    }

    public static function html($meta, $field) {

        $meta = wp_parse_args($meta, [
            'text' => 'Themeperch',
            'url' => '',
            'target' => '',
            'type' => '',
            'style' => '',
            'class' => '',
            'icon' => '',
            'icon_position' => '',
            'attributes' => [],
        ]);

        $output = '<div class="btn-field">';

        // post_type.
        $field_id = sanitize_title($field['field_name']);
        $group = RWMB_Group_Field::normalize([
            'type'        => 'group',
            'id'          => $field_id,
            'field_name'  => $field['field_name'],
            'default' => true,
            'clone' => false,
            'sort_clone' => false,
            'fields' => include __DIR__ . '/fields-btn.php',
        ]);
        $output    .= RWMB_Group_Field::html($meta, $group);

        $output .= '</div>';


        return $output;
    }
}
