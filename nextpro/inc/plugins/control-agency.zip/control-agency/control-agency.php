<?php
/*
Plugin Name: Control Agency - Services & Projects Showcase
Plugin URI: https://themeperch.net/plugins/control-agency
Description: Take Control of Your <strong>Projects</strong>, <strong>Career</strong>, <strong>Services</strong> & <strong>Team members</strong> – no programming knowledge required. This emphasizes the ability to showcase a creative agency's work. Highlighting the four essential post types in one powerful plugin with easy-to-use UI.
Author: Themeperch
Version: 0.1
Author URI: https://themeperch.net/
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || die;

if( defined('CTRL_AGENCY_VER') ) return;

// Constants
define( 'CTRL_AGENCY_URI', trailingslashit(plugin_dir_url( __FILE__ )) );
define( 'CTRL_AGENCY_VER', '0.1' );
define( 'CTRL_AGENCY_ASSETS', trailingslashit(CTRL_AGENCY_URI.'assets') );
define( 'CTRL_AGENCY_DIR', trailingslashit(plugin_dir_path( __FILE__ )) );
define( 'CTRL_AGENCY_TEMPLATEPATH', trailingslashit(plugin_dir_path( __FILE__ ).'views') );
define( 'CTRL_AGENCY_TEMPLATEPATH_URI', trailingslashit(plugin_dir_url( __FILE__ ).'views') );

// include autoloader
if ( !file_exists( ABSPATH.'wp-content/plugins/meta-box/meta-box.php' ) ) {
	//plugin is not activated
    require_once __DIR__ .'/vendor/wpmetabox/meta-box/meta-box.php';
} 
require_once __DIR__ .'/vendor/autoload.php';

// Fire plugin loader
new ControlAgency\Loader;