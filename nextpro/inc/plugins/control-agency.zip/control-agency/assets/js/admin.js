(function($) {
    $(document).on('click', '[data-id="controlAgencyAjax"]', function(){
        // We can also pass the url value separately from ajaxurl for front end AJAX implementations
        $.post(controlAgencyAdmin.ajax, {
            'action': 'controlAgencyAjax',
            'data' : $(this).data(),
            'nonce' : controlAgencyAdmin.nonce
        }, function(response) {
            console.log('Got this from the server: ' + response);
        });
        
        return false;
    });

    
    document.addEventListener('DOMContentLoaded', function() {
        // Select the button with the class .controlAgencyReset
        const resetButton = document.querySelector('.controlAgencyReset');
        
        // Check if the button exists
        if (resetButton) {
            // Add a click event listener to the button
            resetButton.addEventListener('click', function() {
                // Display a confirmation dialog when the button is clicked
                const userConfirmed = confirm('Are you sure you want to reset?');
                
                // Check the user's response
                if (userConfirmed) {
                    resetButton.disabled = true;
                    // User clicked "OK"
                    $.post(controlAgencyAdmin.ajax, {
                        'action': 'controlAgencyAjax',
                        'data' : {
                            'action': 'resetSettings',
                            'option_name': resetButton.getAttribute('data-option_name')
                        },
                        'nonce' : controlAgencyAdmin.nonce
                    }, function(response) {
                        if (response.error === 0) {
                            // Redirect to the URL specified in redirect_to
                            window.location.href = response.redirect_to;
                        }
                        resetButton.disabled = false;
                    });
                }
            });
        } 
    });
})(jQuery, window, document);


