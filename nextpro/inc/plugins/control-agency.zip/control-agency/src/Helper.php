<?php
namespace ControlAgency;

final class Helper{

    public static function include_admin_file($relative_path){
        $filename = __DIR__. "/{$relative_path}";

        if(current_theme_supports('control-agency')):
            $theme_filename = "admin/$relative_path";         
            $located = control_agency_template($theme_filename);
            if ($located) {
                $filename = $located;
            }
        endif;

        if(file_exists($filename)){
            return include $filename;
        }else{
            return false;
        }
    }

    public static function admin_filename($filename){
        if(!current_theme_supports('control-agency')){
            return $filename;
        }

        $theme_filename = str_replace(__DIR__ . "/", 'admin/', $filename);        
        $located = control_agency_template($theme_filename);
        if ($located) {
            $filename = $located;
        }
        
        return $filename;
    }

    public static function admin_files($directory){
        $admin_files = [];
        $files = glob(__DIR__ . "/{$directory}/*.php");
        if (!empty($files)) {
            foreach ($files as $file) {
                $related_path = str_replace(__DIR__ . "/", '', $file);
                $admin_files[$related_path] = $file;
            }
        }

        if(current_theme_supports('control-agency')):
            $templates_dir = apply_filters('control_projects/template_directory', '/control-agency/');
            $theme_files = glob(get_template_directory() . "{$templates_dir}admin/{$directory}/*.php");
            if (!empty($theme_files)) {
                foreach ($theme_files as $theme_file) {
                    $related_path = str_replace(get_template_directory() . "{$templates_dir}admin/", '', $theme_file);
                    $admin_files[$related_path] = $theme_file;
                }
            }
        endif;

        return $admin_files;
    }

    public static function debug_log($log = null){
        if(!WP_DEBUG || !SCRIPT_DEBUG) return;
        if(empty($log) || !is_user_logged_in() || !current_user_can('customize')) return;

        if(is_string($log)){
            echo "<script>console.log('" . $log . "');</script>";
        }else{
            echo "<script>console.log(JSON.parse('" . json_encode($log) . "'));</script>";
        }        
    }

    public static function settings_tab_fields($tab){ 
		global $controlAgency;           
        $fields = [];
		 
		if(in_array($tab, $controlAgency->post_types)){ 
			$post_type = $tab;
			$args = $controlAgency->{$post_type};
			if(empty($args['has_archive'])) return $fields;
			$fields  =   include __DIR__ ."/settings/post-type.php";
		}else{
			$file ="settings/{$tab}.php";
			$fields  =  Helper::include_admin_file($file);
		}       
        return $fields;        
    }
    
    public static function archive_page_help($post_type, $args ){
       
        $options = get_option('control_agency_options', []);
        $post_id = !empty($options["{$post_type}_archive_page"])? $options["{$post_type}_archive_page"] : '';
          
        if(empty($post_id)){
            $output = sprintf(
                '<div id="control-agency-settings-'.$post_type.'"><p><strong>%s</strong> %s</p></div>', 
                esc_attr__('Note:', 'control-agency'),
                sprintf(esc_attr__('Your are using default settings for %s post type.', 'control-agency'), '<a href="'.admin_url('options-general.php?page=control-agency#tab-'.$post_type).'"><strong>'.$args['label'].'</strong></a>'),
            );           
        }else{
            $post = get_post($post_id);
            
            $output = sprintf(
                '<p>%1$s <strong>%5$s</strong>. <a target="_blank" href="'.get_permalink($post_id).'">%2$s</a><br />Slug: <strong>'.$post->post_name.'</strong><br />%4$s. <a target="_blank" href="'.admin_url('post.php?post='.$post_id.'&action=edit').'">%3$s</a></p>', 
                sprintf(esc_attr__('Archive page for %s:', 'control-agency'), $args['label']),  
                esc_attr__('View archive page', 'control-agency'),      
                esc_attr__('Edit archive page', 'control-agency'),      
                esc_attr__('You can edit Archive Slug, Title, Description & Content', 'control-agency'),      
                $post->post_title,
                
            );
        }      

        return $output;
    }

    

}