<?php
namespace ControlAgency;

final class Shortcodes{
	private $prefix = 'control_agency';
	/**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {
        add_action('init', [$this, 'shortcodes'], 20);		      
	}

	public function shortcodes(){
		global $controlAgency;

		add_shortcode('control_agency', [$this, 'render'], 10, 2);
		foreach ($controlAgency->sections as $section_id) {
			add_shortcode($this->prefix.$section_id, [$this, 'render'], 10, 2);
		}
	}

	public function render($atts, $content = null){
		global $controlAgency;
		if(empty($atts['element_id'])) return;		
		$element_id = $atts['element_id'];
		unset($atts['element_id']);

		$section_id = !empty($controlAgency->sections[$element_id])? $controlAgency->sections[$element_id] : false;
		if(empty($section_id)) return;

		if(empty($controlAgency->std[$section_id])) return;

		$atts = $this->prepare_shortcode_atts($atts, $section_id);
		$atts = wp_parse_args($atts, $controlAgency->std[$section_id]);
		
		$template_file = '';
		if(!empty($atts['template'])){
			$template_file = $atts['template'];
			unset($atts['template']);
		}elseif(!empty($atts['template_file'])){
			$template_file = $atts['template_file'];
			unset($atts['template_file']);
		}elseif(!empty($atts['template_style'])){
			$template_file = $atts['template_style'];
			unset($atts['template_style']);
		}

		if(empty($template_file)) return;

		$atts['content'] = $content;

		ob_start();
		control_agency_render_template($template_file, $atts);
		return ob_get_clean();

	}

	private function prepare_shortcode_atts($atts, $section_id){
		global $controlAgency;
		$element = $controlAgency->{$section_id};
		$element_id__type = array_column($element['fields'], 'type', 'id');
		foreach ($atts as $id => $value) {
			$type = $element_id__type[$id];			
			$field = reset(control_agency_array_search_by_key_value($element['fields'], 'id', $id));
			
			switch ($type) {
				case 'text':
					$value = str_replace(['`{`', '`}`'], ['[', ']'], $value);
					if(!empty($field['clone']) && $field['clone']){
						$value = explode(",  ", $value);
					}
					break;

				case 'group':
					
					if(isset($field['clone']) && !$field['clone']){
						$valueArr = explode(",  ", $value);
						$id_map = array_column($field['fields'], 'id');						
						$valueMap = [];						
						foreach ($valueArr as $key => $_value) {
							if(empty($id_map[$key])) continue;
							$valueMap[$id_map[$key]] = $_value;
						}
						$value = $valueMap;
						
					}else{
						$value = json_decode( urldecode( $value ), true );
					}
										
					break;	
					
				case 'image_advanced':
					if(!empty($field['max_file_uploads']) && ($field['max_file_uploads'] > 1)){
						$value = explode(',', $value);
					}
					break; 

				case 'file_input':
					if(intval($value)){
						$default_url = !empty($field['std'])? $field['std'] : '';
						$value = control_agency_get_attachment_url($value, 'full', $default_url);
					}
					
					break;		
				
				default:
					# code...
					break;
			}

			$atts[$id] = $value;
		}

		return $atts;

	}
   
}