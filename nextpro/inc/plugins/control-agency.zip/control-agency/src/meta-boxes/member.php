<?php
return [
    [
        'name' => esc_attr__('Designation', 'control-agency'),
        'id'   => 'designation',
        'type' => 'text',
        'std' => 'Marketing manager',
        'size'   => 60
    ],
];