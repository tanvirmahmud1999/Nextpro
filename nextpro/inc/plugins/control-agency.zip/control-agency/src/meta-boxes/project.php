<?php
return [
    [
        'id'               => 'featured',
        'desc'             => esc_attr__('Featured project?', 'control-agency'),
        'type'             => 'checkbox',
        'tab'  => 'overview',                   
    ]
];