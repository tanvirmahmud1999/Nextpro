<?php
return [    
    [
        'name' => __( 'Experience', 'control-agency' ),
        'id'   => 'experience',
        'type' => 'text',
    ],
    [
        'name' => __( 'Education', 'control-agency' ),
        'id'   => 'education',
        'type' => 'text',
    ],
    [
        'name' => __( 'Application Deadline', 'control-agency' ),
        'id'   => 'application_deadline',
        'type' => 'date',
    ],
    [
        'name' => __( 'Sallary', 'control-agency' ),
        'id'   => 'sallary',
        'type' => 'text',
    ],   
    
];