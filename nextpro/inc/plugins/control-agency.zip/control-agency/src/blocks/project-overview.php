<?php 
return [
    'title'           => 'Project Overview',
    'id'              => 'project-overview',
    'icon'            => 'info-outline',
    'description'     => 'Display project overview',
    'fields'          => [
        [            
            'type' => 'select',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'project/single/overview.php',
            'options' => [
                'project/single/overview.php' => 'Default',
            ] 
        ],
        [
            'type' => 'single_image',
            'id'   => 'image',
            'name' => esc_attr__('Image', 'control-agency'),
            'max_file_uploads' => 1,
            'max_status'       => false,
            'image_size'       => 'full',
        ],
        [
            'type' => 'text',
            'id'   => 'title',
            'name' => esc_attr__('Overview title', 'control-agency'),
            'std'  => 'Overview'
            
        ],
        [
            'type'  => 'textarea',
            'id'    => 'desc',
            'name' => esc_attr('Overview Description', 'neuron'),
            'std' => 'Et blanditiis quae ab porro debitis quo optio fugiat et rerum quod qui incidunt omnis ut impedit dignissimos aut explicabo veniam. Id placeat eveniet a reiciendis inventore ut facere repellendus. Qui tempora magnam et tempora sapiente qui vero cupiditate et maxime iusto ut nobis earum et voluptatem maiores est dolores veniam',
            'tab' => 'overview',
        ],
        [
            'name'     => __( 'Client', 'control-agency' ),
            'id'       => 'client',
            'std'     => control_agency_config('client'),
            'type'     => 'group',
            'clone'     => false,
            'collapsible' => false,
            'fields' => [
                [
                    'type' => 'text',
                    'id'   => 'label',
                    'placeholder' => esc_attr__('Client label', 'control-agency'),
                ],
                [
                    'type' => 'text',
                    'id'   => 'value',
                    'placeholder' => esc_attr__('Client name', 'control-agency'),
                ],
            ],
        ],
        [
            'name'     => __( 'Release date', 'control-agency' ),
            'id'       => 'release',
            'std'     => control_agency_config('release'),
            'type'     => 'group',
            'clone'     => false,
            'collapsible' => false,
            'fields' => [
                [
                    'type' => 'text',
                    'id'   => 'label',
                    'placeholder' => esc_attr__('Release label', 'control-agency'),
                ],
                [
                    'type' => 'text',
                    'id'   => 'value',
                    'placeholder' => esc_attr__('Release date', 'control-agency'),
                ],
            ],
        ],
        [
            'name'     => __( 'Project types', 'control-agency' ),
            'id'       => 'types',
            'std'     => control_agency_config('types'),
            'type'     => 'group',
            'clone'     => false,
            'collapsible' => false,
            'fields' => [
                [
                    'type' => 'text',
                    'id'   => 'label',
                    'placeholder' => esc_attr__('Types label', 'control-agency'),
                ],
                [
                    'type' => 'text',
                    'id'   => 'value',
                    'placeholder' => esc_attr__('Types', 'control-agency'),                   
                ],
            ],
        ],
        [
            'name'     => __( 'Website', 'control-agency' ),
            'id'       => 'website',
            'std'     => control_agency_config('website'),
            'type'     => 'group',
            'clone'     => false,
            'collapsible' => false,
            'fields' => [
                [
                    'type' => 'text',
                    'id'   => 'label',
                    'placeholder' => esc_attr__('Website label', 'control-agency'),
                ],
                [
                    'type' => 'text',
                    'id'   => 'value',
                    'placeholder' => esc_attr__('Website link', 'control-agency'),                   
                ],
            ],
        ],  
      
                
    ],
];