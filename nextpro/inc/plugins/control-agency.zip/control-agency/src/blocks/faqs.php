<?php 
return [
    'title'           => esc_attr__('FAQs', 'control-agency'),
    'id'              => 'faqs',
    'icon'            => 'info-outline',
    'description'     => 'Display question & answer',        
    'fields'          => [
        [
           'type' => 'select',
            'id' => 'template',
            'name' => 'Template style',
            'std' => 'blocks/faqs.php',
            'options' => [
                'blocks/faqs.php' => 'Default'
            ]
        ],
        [
            'name'        => esc_attr__('Title:', 'control-agency'),
            'id'          => 'title',
            'desc'        => esc_attr__('Add Title to this Section', 'control-agency'),
            'type'        => 'text',
            'std'         => 'FAQs',
            'size'         => 60,
            'placeholder' => esc_attr__('FAQs',   'control-agency'),
        ],
        [
            'id'               => 'title_image',
            'name'             => esc_attr__('Title Image',  'control-agency'),
            'desc'             => esc_attr__('Add or Change Image to Left Side', 'control-agency'),
            'type'             => 'single_image',
            'image_size'       => 'full',
            'std'              =>''
        ], 
        [
            'name'        => esc_attr__('Subtitle:', 'control-agency'),
            'id'          => 'subtitle',
            'desc'        => esc_attr__('Add Subtitle to this Section', 'control-agency'),
            'type'        => 'text',
            'std'         => 'Still no luck? We can help!',
            'placeholder' => esc_attr__('Still no luck? We can help!',   'control-agency'), 
        ],
        [
            'name'        => esc_attr__('Description:', 'control-agency'),
            'id'          => 'desc',
            'desc'        => esc_attr__('Add Description Here', 'control-agency'),
            'type'        => 'textarea',
            'std'         => 'Contact us and we’ll get back to you as soon as possible',
            'placeholder' => esc_attr__('Description',   'control-agency'),
        ],
        [
            'name'        => esc_attr__('Button:', 'control-agency'),
            'id'          => 'button_text',
            'desc'        => esc_attr__('Button name', 'control-agency'),
            'type'        => 'text',
            'std'         => 'Contact Us',
            'placeholder' => esc_attr__('Contact Us', 'control-agency'),
        ],
        [
            'name'        => esc_attr__('Button URL:', 'control-agency'),
            'id'          => 'button_url',
            'desc'        => esc_attr__('URL for the button', 'control-agency'),
            'type'        => 'text',
            'placeholder' => esc_attr__('Enter button URL here', 'control-agency'), 
            'std'         => '#',         
        ],
        [   'name'        => esc_attr__('FAQ:', 'control-agency'),
            'id'                => 'faqs',
            'type'              => 'group',
            'clone'             => true,
            'clone_default'     => true,
            'clone_as_multiple' => true,
            'collapsible'   => true,
            'default_state'   => 'collapsed',
            'group_title'   => '{#}. {question}',
            'max_clone'         => 10,
            'desc'        => esc_attr__('Click the button to add new', 'control-agency' ),
            'add_button'        => esc_attr__('Add FAQ', 'control-agency' ),
            'std'               => [
                [
                    'question' => 'Where is my order? Quisque molestie',
                    'answer' => 'Vel tenetur officiis ab reiciendis dolor aut quae doloremque est ipsum natus et consequatur animi aut sunt dolores ut quasi rerum. Aut velit velit id quasi velit eum reiciendis laudantium quo galisum incidunt aut velit animi hic temporibus blanditiis sit odit iure. Eum laborum dolores ea molestias fuga qui temporibus accusantium qui soluta aliquid ab vero soluta.',
                ],
                [
                    'question' => 'Can I cancel or change my order?',
                    'answer' => 'Vel tenetur officiis ab reiciendis dolor aut quae doloremque est ipsum natus et consequatur animi aut sunt dolores ut quasi rerum. Aut velit velit id quasi velit eum reiciendis laudantium quo galisum incidunt aut velit animi hic temporibus blanditiis sit odit iure. Eum laborum dolores ea molestias fuga qui temporibus accusantium qui soluta aliquid ab vero soluta.',
                ],
                [
                    'question' => 'I have promotional or discount code?',
                    'answer' => 'Vel tenetur officiis ab reiciendis dolor aut quae doloremque est ipsum natus et consequatur animi aut sunt dolores ut quasi rerum. Aut velit velit id quasi velit eum reiciendis laudantium quo galisum incidunt aut velit animi hic temporibus blanditiis sit odit iure. Eum laborum dolores ea molestias fuga qui temporibus accusantium qui soluta aliquid ab vero soluta.',
                ],
                [
                    'question' => 'What are the delivery types you use?',
                    'answer' => 'Vel tenetur officiis ab reiciendis dolor aut quae doloremque est ipsum natus et consequatur animi aut sunt dolores ut quasi rerum. Aut velit velit id quasi velit eum reiciendis laudantium quo galisum incidunt aut velit animi hic temporibus blanditiis sit odit iure. Eum laborum dolores ea molestias fuga qui temporibus accusantium qui soluta aliquid ab vero soluta.',
                ],
                [
                    'question' => 'Can I cancel or change my order?',
                    'answer' => 'Vel tenetur officiis ab reiciendis dolor aut quae doloremque est ipsum natus et consequatur animi aut sunt dolores ut quasi rerum. Aut velit velit id quasi velit eum reiciendis laudantium quo galisum incidunt aut velit animi hic temporibus blanditiis sit odit iure. Eum laborum dolores ea molestias fuga qui temporibus accusantium qui soluta aliquid ab vero soluta.',
                ],
                
            ],
            'fields'            => [
                
                [
                    'name' => esc_attr__( 'Question', 'control-agency' ),
                    'id'   => 'question',
                    'type' => 'text',
                ],            
                        
                [
                    'name' => esc_attr__( 'Answer', 'control-agency' ),
                    'id'   => 'answer',
                    'type'    => 'wysiwyg',
                    'raw'     => false,
                    'options' => [
                        'textarea_rows' => 4,
                        'teeny'         => true,
                        'media_buttons' => false,
                        'dfw' => false,
                        'quicktags' => false,
                        'tinymce' => false
                    ],
                ],
                
                
            ],
        ],        
        [
            'id'               => 'faqs_images',
            'name'             => esc_attr__('Faqs gallery',  'control-agency'),
            'desc'             => esc_attr__('Add or Change Image to Right Side', 'control-agency'),
            'type'             => 'image_advanced',
            'force_delete'     => true,
            'max_file_uploads' => 2,
            'max_status'       => true,
            'image_size'       => 'thumbnail',
            'std'              =>''
        ],        
    ],
];