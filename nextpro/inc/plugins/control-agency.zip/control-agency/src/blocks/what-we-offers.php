<?php 
return [
    'title'           => 'What we offers',
    'id'              => 'what-we-offers',
    'icon'            => 'phone',
    'description'     => sprintf('This element contain %s', '<code>What we offers</code>, <code>Services carousel</code>'),     
    'fields'          => [
        [
            
            'type' => 'hidden',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'blocks/what-we-offers.php',
            'options' => [
                'blocks/what-we-offers.php' => 'What we offers',
            ]
        ],
        [
            'name'        => esc_attr__('Title:', 'control-agency'),
            'id'          => 'title',
            'desc'        => esc_attr__('Add title to this Section', 'control-agency'),
            'type'        => 'text',
            'size'        => 60,
            'std'         => '{Services} What We Offer',
            'placeholder' => esc_attr__('Section title',   'control-agency'),
        ],
        [
            'name'        => esc_attr__('Subtitle:', 'control-agency'),
            'id'          => 'subtitle',
            'desc'        => esc_attr__('Add title to this Section', 'control-agency'),
            'type'        => 'textarea',
            'std'         => '',
            'placeholder' => esc_attr__('Enter description here...',   'control-agency'),
        ],
        [
            'name' => esc_attr__( 'Services', 'control-agency' ),
            'id'   => 'services',
            'type' => 'group',
            'clone' => true,
            'max_clone' => 10,
            'min_clone' => 10,
            'collapsible' => true,
            'default_state' => 'collapsed',
            'group_title' => '{#}. {title}',
            'std'   => [
                [
                    'icon' => get_theme_file_uri('assets/imgs/page/homepage5/keyword.svg'),
                    'title' => 'Keyword research',
                    'subtitle' => 'Donec mollis id eros semper consectetur. Donec imperdiet enim consectetur enim posuere eleifend. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
                    'button_text' => 'DISCOVER',
                    'button_url' => '#',
                    'class' => '',
                ],
                [
                    'icon' => get_theme_file_uri('assets/imgs/page/homepage5/ranking.svg'),
                    'title' => 'Keyword ranking',
                    'subtitle' => 'Donec mollis id eros semper consectetur. Donec imperdiet enim consectetur enim posuere eleifend. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
                    'button_text' => 'DISCOVER',
                    'button_url' => '#',
                    'class' => '',
                ],
                [
                    'icon' => get_theme_file_uri('assets/imgs/page/homepage5/performent.svg'),
                    'title' => 'Performance',
                    'subtitle' => 'Donec mollis id eros semper consectetur. Donec imperdiet enim consectetur enim posuere eleifend. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
                    'button_text' => 'DISCOVER',
                    'button_url' => '#',
                    'class' => '',
                ],
                [
                    'icon' => get_theme_file_uri('assets/imgs/page/homepage5/cost.svg'),
                    'title' => 'Cost-effective',
                    'subtitle' => 'Donec mollis id eros semper consectetur. Donec imperdiet enim consectetur enim posuere eleifend. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
                    'button_text' => 'DISCOVER',
                    'button_url' => '#',
                    'class' => '',
                ],
                [
                    'icon' => get_theme_file_uri('assets/imgs/page/homepage5/site.svg'),
                    'title' => 'Site health optimization',
                    'subtitle' => 'Donec mollis id eros semper consectetur. Donec imperdiet enim consectetur enim posuere eleifend. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
                    'button_text' => 'DISCOVER',
                    'button_url' => '#',
                    'class' => '',
                ],
            ],
            'fields'  => [
                [
                    'name'        => esc_attr__('Icon', 'control-agency'),
                    'id'          => 'icon',
                    'desc'        => esc_attr__('Upload or enter service icon URL', 'control-agency'),
                    'type'        => 'file_input',
                    'class'        => 'dark-preview preview-only',
                    'size' => 60, 
                    'mime_type'  => implode(',', [ 'jpeg', 'jpg', 'png', 'gif', 'svg'])
                ],
                [
                    'name'        => esc_attr__('Title', 'control-agency'),
                    'id'          => 'title',
                    'desc'        => esc_attr__('Enter service title', 'control-agency'),
                    'type'        => 'text',
                    'size' => 60,   
                ],
                [
                    'name'        => esc_attr__('Subtitle', 'control-agency'),
                    'id'          => 'subtitle',
                    'desc'        => esc_attr__('Enter service short description', 'control-agency'),
                    'type'        => 'textarea',
                ],
                [
                    'name'        => esc_attr__('Button Text:', 'control-agency'),
                    'id'          => 'button_text',
                    'desc'        => esc_attr__('Enter Button Text', 'control-agency'),
                    'type'        => 'text',
                    'size' => 60,   
                ],
                [
                    'name'        => esc_attr__('Button URL:', 'control-agency'),
                    'id'          => 'button_url',
                    'desc'        => esc_attr__('URL for the button', 'control-agency'),
                    'type'        => 'text',
                    'size' => 60,   
                    'placeholder' => esc_attr__('Enter button URL here', 'control-agency'), 
                    'visible' => ['button_text', '!=', '']       
                ],
                [
                    'name'        => esc_attr__('Extra CSS class', 'control-agency'),
                    'id'          => 'class',
                    'type'        => 'text',
                             
                ],
            ],
            
        ],
        [            
            'type' => 'select',
            'id' => 'display_footer',
            'name' => 'Display Footer?',
            'std' => 'yes',
            'options' => [
                'yes' => 'Yes',
                'no' => 'No'
            ],
        ],
        [
            'name'        => esc_attr__('Button Text:', 'control-agency'),
            'id'          => 'button_text',
            'desc'        => esc_attr__('Edit Button Text', 'control-agency'),
            'type'        => 'text',
            'size' => 60,   
            'placeholder' => esc_attr__('GET A QUOTE', 'control-agency'),   
            'visible'     => ['display_footer', '=', 'yes'],                 
        ],
        [
            'id'               => 'button_image',
            'name'             => esc_attr__('Button icon Image:',  'control-agency'),
            'type'             => 'single_image',
            'desc'             => esc_attr__('Add image to button', 'control-agency'),
            'image_size'       => 'thumbnail',     
            'std'              =>'',
            'visible'     => ['display_footer', '=', 'yes'],   
        ],
        [
            'name'        => esc_attr__('Button URL:', 'control-agency'),
            'id'          => 'button_url',
            'desc'        => esc_attr__('URL for the button', 'control-agency'),
            'type'        => 'text',
            'std'         => '#',
            'size' => 60,   
            'placeholder' => esc_attr__('Enter button URL here', 'control-agency'), 
            'visible'     => ['display_footer', '=', 'yes'],
                     
        ],
        [
            'name'        => esc_attr__('Footer', 'control-agency'),
            'id'          => 'footer_desc',
            'desc'        => esc_attr__(' Leave blank to avoid this field', 'control-agency'),
            'type'        => 'textarea',
            'std'         => "(+01) 234 567 89 - (+01) 456 789 21 Hours: 8:00 - 17:00, Mon - Sat",
            'placeholder' => esc_attr__('Archive footer description...',   'control-agency'), 
            'visible'     => ['display_footer', '=', 'yes'],
        ],
        
    ],
];
