<?php 
return [
    'title'           => 'Image Parallax',
    'id'              => 'project-parallax',
    'icon'            => 'format-image',
    'description'     => 'Display project overview',
    'fields'          => [
        [            
            'type' => 'select',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'project/single/media-parallax.php',
            'options' => [
                'project/single/media-parallax.php' => 'Default',
            ] 
        ],
        [
            'id'               => 'parallax_image',
            'name'             => esc_attr__('Parallax image', 'control-agency'),
            'desc'             => esc_attr__('Used for single project parallax inmage in content', 'control-agency'),
            'type'             => 'image_advanced',
            'force_delete'     => false,
            'max_file_uploads' => 1,
            'max_status'       => false,
            'image_size'       => 'full',
        ],       
        [
            'type'  => 'textarea',
            'id'    => 'parallax_desc',
            'name' => esc_attr('Banner Description', 'neuron'),
            'std' => 'Et blanditiis quae ab porro debitis quo optio fugiat et rerum quod qui incidunt omnis ut impedit dignissimos aut explicabo veniam. Id placeat eveniet a reiciendis inventore ut facere repellendus. Qui tempora magnam et tempora sapiente qui vero cupiditate et maxime iusto ut nobis earum et voluptatem maiores est dolores veniam',
        ],
      
                
    ],
];