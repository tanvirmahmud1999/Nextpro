<?php 
return [
    'title'           => 'Area of expertise',
    'id'              => 'area-of-expertise',
    'icon'            => 'chart-area',
    'description'     => sprintf('This element contain %s', '<code>What we offers</code>, <code>Services carousel</code>'),     
    'fields'          => [
        [
            
            'type' => 'hidden',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'member/single/area-of-expertise.php',
            'options' => [
                'member/single/area-of-expertise.php' => 'Area of Expertise',
            ]
        ],
        [
            'name' => esc_attr__('Title', 'control-agency'),
            'id'   => 'title',
            'type' => 'textarea',
            'std' => "My key areas {of} Expertise",
            'desc' => 'Area of Expertise title',
        ],
        [
            'name' => esc_attr__('Description', 'control-agency'),
            'id'   => 'desc',
            'type' => 'textarea',
            'std' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum suscipit debitis quam dignissimos veritatis atque pariatur magnam obcaecati fugit',
        ],
        [
            'name' => 'Expertises',
            'id'   => 'expertises',
            'type' => 'group',
            'clone'     => true,
            'collapsible' => true,
            'save_state' => false,
            'default_state' => 'collapsed',
            'add_button' => esc_attr__('+ Area of Expertise', 'control-agency'),
            'group_title'   => '{#}: {title}',
            'std'  => [
                [                   
                    'icon' => 'digital',
                    'title' => 'Social Media',
                    'subtitle' => 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit laborum — semper quis lectus nulla.',
                ],
                [                   
                    'icon' => 'digital',
                    'title' => 'Digital Marketing',
                    'subtitle' => 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit laborum — semper quis lectus nulla.',
                ],
                [
                  
                    'icon' => 'development',
                    'title' => 'Web Development',
                    'subtitle' => 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit laborum — semper quis lectus nulla.',
                ]                
            ],
            'fields' => [                
                [
                    'name' => esc_attr__('Icon SVG', 'control-agency'),
                    'id'   => 'icon',
                    'type' => 'select',
                    'options' => ControlAgency\SVG_Icons::options()
                ],
                [
                    'name' => esc_attr__('Title', 'control-agency'),
                    'id'   => 'title',
                    'type' => 'text',
                    'placeholder' => 'Enter expertise title...',
                ],
                [
                    'name' => esc_attr__('Title', 'control-agency'),
                    'id'   => 'subtitle',
                    'type' => 'textarea',
                    'placeholder' => 'Enter expertise description...',
                ],
            ]
        ],
        [
            'name' => esc_attr__('Button text', 'control-agency'),
            'id'   => 'button_text',
            'type' => 'text',
            'std' => 'Contact Us',
        ],
        [
            'name' => esc_attr__('Button URL', 'control-agency'),
            'id'   => 'button_url',
            'type' => 'text',
            'std' => '#',
        ],
        [
            'name' => esc_attr__('Footer text', 'control-agency'),
            'id'   => 'footer_text',
            'type' => 'text',
            'std' => 'Get Started Get Started Get Started',
        ],
        
        
    ],
];
