<?php 
return [
    'title'           => 'Post Content',
    'id'              => 'editor-content',
    'disable_block'   => true,
    'icon'            => 'text',
    'description'     => 'Display name, title, shot description & button',    
    'fields'          => [
        [
            
            'type' => 'select',
            'id' => 'template',
            'name' => 'Content style',
            'std' => 'member/single/content.php',
            'options' => [
                'project/single/content.php' => 'Project content',
                'service/single/content.php' => 'Service content',
                'member/single/content.php' => 'Team member content',
                'job/single/content.php' => 'Job content',
            ],
        ],  
        [
            'name'        => esc_attr__('Title', 'control-agency'),
            'id'          => 'title',
            'type'        => 'text',
            'std'         => '',
            'size' => 60,         
            'placeholder' => esc_attr__('Enter title...',   'control-agency'),         
        ],
        [
            'name'        => esc_attr__('Content', 'control-agency'),
            'type'        => 'custom_html',
            'desc'         => 'Editor content will be displayed',
        ],
        [
            'name' => esc_attr__('Signature - Dark', 'control-agency'),
            'id'   => 'signature',
            'type' => 'file_input',
            'std' => get_theme_file_uri('assets/imgs/page/about-2/sign.png'),
            'desc' => 'Used for member content',
            'visible' => ['template', '=', 'member/single/content.php']
        ],
        [
            'name' => esc_attr__('Signature - light', 'control-agency'),
            'id'   => 'signature_white',
            'type' => 'file_input',
            'std' => get_theme_file_uri('assets/imgs/page/about-2/sign-w.png'),
            'desc' => 'Used for member content',
            'visible' => ['template', '=', 'member/single/content.php']
        ],

    ],
];