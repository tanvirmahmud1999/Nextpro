<?php 
return [
    'title'           => 'Projects template',
    'id'              => 'projects-template',
    'icon'            => 'portfolio',
    'description'     => 'Display Projects by WP Query.',
    'fields'          => [
        [            
            'type' => 'select',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'project/template-grid.php',
            'options' => [
                'project/template-grid.php' => 'Projects grid',
                'project/template-isotope.php' => 'Projects isotope ',
                'project/template-gallery.php' => 'Projects gallery',
                'project/single/related.php' => 'Projects Carousel',
            ] 
        ],
        [
            'name'        => esc_attr__('Title', 'neuron'),
            'id'          => 'title',
            'desc'        => esc_attr__('Type your title here', 'neuron'),
            'type'        => 'text',
            'std'         => 'Recent {Work}',
            'size' => 60, 
            'placeholder' => esc_attr__('Title',   'neuron'), 
                     
        ],        
        [
            'name'        => esc_attr__('Subtitle', 'neuron'),
            'id'          => 'subtitle',
            'desc'        => esc_attr__('Type your title here', 'neuron'),
            'type'        => 'textarea',
            'std'         => 'Projects',
            'placeholder' => esc_attr__('Subtitle',   'neuron'), 
                     
        ], 
        [
            'name'        => esc_attr__('Button Text:', 'control-agency'),
            'id'          => 'button_text',
            'desc'        => esc_attr__('Edit Button Text', 'control-agency'),
            'type'        => 'text',
            'size' => 60,   
            'placeholder' => esc_attr__('Show More Projects', 'control-agency'),   
            'visible'     => ['template', 'in', ['projects/template-gallery.php', 'projects/template-isotope.php']]               
        ],
        [
            'name'        => esc_attr__('Button URL:', 'control-agency'),
            'id'          => 'button_url',
            'desc'        => esc_attr__('URL for the button', 'control-agency'),
            'type'        => 'text',
            'std'         => '#',
            'size' => 60,   
            'placeholder' => esc_attr__('Enter button URL here', 'control-agency'), 
            'visible'     => ['template', 'in', ['projects/template-gallery.php', 'projects/template-isotope.php']]
                     
        ], 
        [
            'name'        => esc_attr__('Rotating text', 'neuron'),
            'id'          => 'desc',
            'type'        => 'text',
            'std' => '', 
            'size' => 60, 
            'visible'          => ['template', '=', 'projects/template-grid.php']
                 
        ],        
        [            
            'type' => 'select',
            'id' => 'query',
            'name' => 'Project Query',
            'std' => '',
            'options' => control_agency_post_type_query_options('controlproject', ['' => 'Default Query']),
        ], 
      
                
    ],
];