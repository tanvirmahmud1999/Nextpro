<?php 
return [
    'title'           => 'Banner single',
    'id'              => 'banner-single',
    'icon'            => 'cover-image',
    'description'     => 'Display name, title, shot description & button',    
    'fields'          => [
        [
            
            'type' => 'hidden',
            'id' => 'template',
            'name' => 'Banner style',
            'std' => 'blocks/banner-single.php',           
        ],   
        [
            'id'   => 'image',
            'name' => 'Image',
            'type' => 'single_image',
            'std'  =>'',
            'desc'  =>'Use for the element',
        ],     
        [
            'name'        => esc_attr__('Title', 'control-agency'),
            'id'          => 'title',
            'desc'        => sprintf(esc_attr__('Type your title here. use %s to display post title. Leave blank to display %s', 'control-agency'), '<code>[post_title]</code>', '<code>Post title</code>'),
            'type'        => 'text',
            'std'         => '',
            'size' => 60,         
            'placeholder' => esc_attr__('Enter title...',   'control-agency'),         
        ],
        [
            'name'        => esc_attr__('Subtitle', 'control-agency'),
            'id'          => 'subtitle',
            'desc'        => esc_attr__('Type Subtitle', 'control-agency'),
            'type'        => 'textarea',
            'std'         => 'Get Right Solution For Business',
            'placeholder' => esc_attr__('Subtitle...',   'control-agency'),    
        ],        
        [
            'name' => esc_attr__( 'Buttons', 'control-agency' ),
            'id'   => 'buttons',
            'type' => 'group',
            'clone' => true,
            'max_clone' => 2,
            'collapsible' => true,
            'default_state' => 'collapsed',
            'group_title' => '{#}. {text}',
            'std'   => [
                [
                    'text' => 'GET STARTED',
                    'url' => '#',
                    'class' => ''
                ],
                [
                    'text' => 'GET A QUOTE',
                    'url' => '#',
                    'class' => ''
                ]
            ],
            'fields'  => [
                [
                    'name'        => esc_attr__('Button Text:', 'control-agency'),
                    'id'          => 'text',
                    'desc'        => esc_attr__('Edit Button Text', 'control-agency'),
                    'type'        => 'text',
                    'size' => 60,   
                    'placeholder' => esc_attr__('GET STARTED', 'control-agency'),                    
                ],
                [
                    'name'        => esc_attr__('Button URL:', 'control-agency'),
                    'id'          => 'url',
                    'desc'        => esc_attr__('URL for the button', 'control-agency'),
                    'type'        => 'text',
                    'std'         => '#',
                    'size' => 60,   
                    'placeholder' => esc_attr__('Enter button URL here', 'control-agency'), 
                             
                ],
                [
                    'name'        => esc_attr__('Target', 'control-agency'),
                    'id'          => 'target',
                    'type'        => 'select',
                    'std'         => '',
                    'options'    => [
                        '' => 'Open in same window',
                        '_blank' => 'Open in new window',
                    ],
                             
                ],
                [
                    'name'        => esc_attr__('CSS class', 'control-agency'),
                    'id'          => 'class',
                    'type'        => 'text',
                    'std'         => '',
                             
                ],
            ],
           
        ], 
        

    ],
];