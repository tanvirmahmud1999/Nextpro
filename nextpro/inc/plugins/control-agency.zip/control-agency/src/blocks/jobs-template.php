<?php 
return [
    'title'           => 'Jobs template',
    'id'              => 'jobs-template',
    'icon'            => 'id-alt',
    'disable_block'   => true,
    'description'     => 'Display Jobs by WP Query.',
    'fields'          => [
        [            
            'type' => 'select',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'job/template-grid.php',
            'options' => [
                'job/template-grid.php' => 'Jobs grid',
                'job/template-carousel.php' => 'Jobs carousel',               
            ] 
        ],
        [
            'name'        => esc_attr__('Title', 'neuron'),
            'id'          => 'title',
            'desc'        => esc_attr__('Type your title here', 'neuron'),
            'type'        => 'text',
            'std'         => 'Recent {Jobs}',
            'size' => 60, 
            'placeholder' => esc_attr__('Title',   'neuron'), 
                     
        ],        
        [
            'name'        => esc_attr__('Subtitle', 'neuron'),
            'id'          => 'subtitle',
            'desc'        => esc_attr__('Type your title here', 'neuron'),
            'type'        => 'textarea',
            'std'         => '',
            'placeholder' => esc_attr__('Subtitle...',   'neuron'), 
                     
        ],
        [            
            'type' => 'select',
            'id' => 'query',
            'name' => 'Jobs Query',
            'std' => '',
            'options' => control_agency_post_type_query_options('controljob', ['' => 'Default Query']),
        ], 
      
                
    ],
];