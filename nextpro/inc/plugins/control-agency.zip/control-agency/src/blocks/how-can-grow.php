<?php 
return [
    'title'           => 'How can grow',
    'id'              => 'how-can-grow',
    'icon'            => 'insert-before',
    'description'     => 'Work Process: How we can help grow',     
    'fields'          => [
        [
            
            'type' => 'hidden',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'blocks/how-can-grow.php',
            'options' => [
                'blocks/how-can-grow.php' => 'How we can help grow',
            ]
        ],
        [
            'name'        => esc_attr__('Title:', 'control-agency'),
            'id'          => 'title',
            'desc'        => esc_attr__('Add title to this Section', 'control-agency'),
            'type'        => 'text',
            'size'        => 60,
            'std'         => '{Work} How we can help grow',
            'placeholder' => esc_attr__('Section title',   'control-agency'),
        ],
        [
            'name'        => esc_attr__('Subtitle:', 'control-agency'),
            'id'          => 'subtitle',
            'desc'        => esc_attr__('Add title to this Section', 'control-agency'),
            'type'        => 'textarea',
            'std'         => '',
            'placeholder' => esc_attr__('Enter description here...',   'control-agency'),
        ],
        [
            'name' => esc_attr__( 'Work Steps', 'control-agency' ),
            'id'   => 'steps',
            'type' => 'group',
            'clone' => true,
            'max_clone' => 10,
            'min_clone' => 2,
            'collapsible' => true,
            'default_state' => 'collapsed',
            'group_title' => '{#}. {title}',
            'std'   => [
                [
                    'image' => get_theme_file_uri('assets/imgs/page/homepage3/work.png'),
                    'title' => 'Stunning Webflow websites',
                    'subtitle' => 'Build custom blogs, portfolios, ecommerce stores, and more with a flexible CMS. Experience the power of HTML, CSS, and JavaScript in a 100% visual canvas. Export code for download.',
                    'number' => '',
                    'class' => '',
                ],
                [
                    'image' => get_theme_file_uri('assets/imgs/page/homepage3/work2.png'),
                    'title' => 'Shopify websites that sell',
                    'subtitle' => 'The #1 Marketplace for Shopify stores. We are the largest marketplace to buy and sell online businesses, websites and digital assets. Start your search or get a valuation today.',
                    'number' => '',
                    'class' => '',
                ],
                [
                    'image' => get_theme_file_uri('assets/imgs/page/homepage3/work3.png'),
                    'title' => 'UI/UX Design',
                    'subtitle' => 'As a UX and UI design services company, we follow modern trends and work hand-in-hand with the development team to create the most effective UX/UI solutions for web, iOS, and Android',
                    'number' => '',
                    'class' => '',
                ],                
            ],
            'fields'  => [
                [
                    'name'        => esc_attr__('Image', 'control-agency'),
                    'id'          => 'image',
                    'desc'        => esc_attr__('Upload or enter step image URL', 'control-agency'),
                    'type'        => 'file_input',
                    'class'        => 'preview-only',
                    'mime_type'  => implode(',', [ 'jpeg', 'jpg', 'png', 'gif', 'svg'])
                ],
                [
                    'name'        => esc_attr__('Title', 'control-agency'),
                    'id'          => 'title',
                    'desc'        => esc_attr__('Enter service title', 'control-agency'),
                    'type'        => 'text',
                    'size' => 60,   
                ],
                [
                    'name'        => esc_attr__('Subtitle', 'control-agency'),
                    'id'          => 'subtitle',
                    'desc'        => esc_attr__('Enter service short description', 'control-agency'),
                    'type'        => 'textarea',
                    'std'         => '',                             
                ],
                [
                    'name'        => esc_attr__('Process number(optional)', 'control-agency'),
                    'id'          => 'number',
                    'desc'        => esc_attr__('Process number', 'control-agency'),
                    'type'        => 'number',
                    'size' => 40,   
                    'min' => 1,   
                    'max' => 10,   
                    'step' => 1,   
                ],                
                [
                    'name'        => esc_attr__('Extra CSS class', 'control-agency'),
                    'id'          => 'class',
                    'type'        => 'text',
                    'std'         => '',
                             
                ],
            ],
            
        ],
        [            
            'type' => 'select',
            'id' => 'display_footer',
            'name' => 'Display Footer?',
            'std' => 'no',
            'options' => [
                'yes' => 'Yes',
                'no' => 'No'
            ],
        ],
        [
            'name'        => esc_attr__('Button Text:', 'control-agency'),
            'id'          => 'button_text',
            'desc'        => esc_attr__('Edit Button Text', 'control-agency'),
            'type'        => 'text',
            'size' => 60,   
            'placeholder' => esc_attr__('GET A QUOTE', 'control-agency'),   
            'visible'     => ['display_footer', '=', 'yes'],                 
        ],
        [
            'id'               => 'button_image',
            'name'             => esc_attr__('Button icon Image:',  'control-agency'),
            'type'             => 'single_image',
            'desc'             => esc_attr__('Add image to button', 'control-agency'),
            'image_size'       => 'thumbnail',     
            'std'              =>'',
            'visible'     => ['display_footer', '=', 'yes'],   
        ],
        [
            'name'        => esc_attr__('Button URL:', 'control-agency'),
            'id'          => 'button_url',
            'desc'        => esc_attr__('URL for the button', 'control-agency'),
            'type'        => 'text',
            'std'         => '#',
            'size' => 60,   
            'placeholder' => esc_attr__('Enter button URL here', 'control-agency'), 
            'visible'     => ['display_footer', '=', 'yes'],
                     
        ],
        [
            'name'        => esc_attr__('Footer', 'control-agency'),
            'id'          => 'footer_desc',
            'desc'        => esc_attr__(' Leave blank to avoid this field', 'control-agency'),
            'type'        => 'textarea',
            'std'         => "(+01) 234 567 89 - (+01) 456 789 21 Hours: 8:00 - 17:00, Mon - Sat",
            'placeholder' => esc_attr__('Archive footer description...',   'control-agency'), 
            'visible'     => ['display_footer', '=', 'yes'],
        ],
        
    ],
];
