<?php 
return [
    'title'           => esc_attr__('Customer Testimonial', 'control-agency'),
    'id'              => 'testimonials',
    'icon'            => 'editor-quote',
    'description'     => 'This is Customer Testimonial Section',    
    'fields'          => [
        [           
            'type'  => 'hidden',
            'id'    => 'template',
            'name'    => 'Template',
            'std'   => 'blocks/testimonials.php',           
        ],
        [
            'name'        => esc_attr__('Name', 'control-agency'),
            'id'          => 'name',
            'desc'        => esc_attr__('Type your section name here', 'control-agency'),
            'type'        => 'text',
            'std'         => 'Testimonials',
            'placeholder' => esc_attr__('Section name...',   'control-agency'),          
        ],
        [
            'name'        => esc_attr__('Title', 'control-agency'),
            'id'          => 'title',
            'desc'        => esc_attr__('Optional. Leave blank to avoid this field', 'control-agency'),
            'type'        => 'textarea',
            'std'         => 'Our {Happy Customers}',
            'placeholder' => esc_attr__('Section title...',   'control-agency'),          
        ],
        [
            'name'        => esc_attr__('Subtitle', 'control-agency'),
            'id'          => 'subtitle',
            'type'        => 'textarea',
            'std'         => '{Control Agency} is loved and trusted by thousands, Here\'s what our amazing clients are saying',
            'placeholder' => esc_attr__('Section subtitle here...',   'control-agency'),          
        ],
        [
            'name'        => 'Enable section button',
            'id'          => 'enable_section_title_button',
            'type'        => 'checkbox',
            'std'         => true,
        ],
        [
            'name' => esc_attr__( 'Section buttons', 'control-agency' ),
            'id'   => 'buttons',
            'type' => 'group',
            'clone' => true,
            'max_clone' => 2,
            'collapsible' => true,
            'default_state' => 'collapsed',
            'group_title' => '{#}. {btn_title}',
            'visible' => ['enable_section_title_button', '=', true],
            'std'   => [
                [
                    'btn_title' => 'View all Reviews',
                    'btn_url' => '#',
                    'btn_class' => 'btn btn-outline-primary'
                ],
            ],
            'fields'  => [
                [
                    'name'        => esc_attr__('Button Text:', 'control-agency'),
                    'id'          => 'btn_title',
                    'desc'        => esc_attr__('Edit Button Text', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('Enter button text...', 'control-agency'),                    
                ],
                [
                    'name'        => esc_attr__('Button URL:', 'control-agency'),
                    'id'          => 'btn_url',
                    'desc'        => esc_attr__('URL for the button', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('https://', 'control-agency'), 
                             
                ],
                [
                    'name'        => esc_attr__('Target', 'control-agency'),
                    'id'          => 'btn_target',
                    'type'        => 'select',
                    'std'         => '',
                    'options'    => [
                        '' => 'Open in same window',
                        '_blank' => 'Open in new window',
                    ],
                             
                ],
                [
                    'name'        => esc_attr__('CSS class', 'control-agency'),
                    'id'          => 'btn_class',
                    'type'        => 'text',
                    'std'         => '',
                             
                ],
            ],
           
        ],
        [
            'name'                => esc_attr__('Testimonials Group', 'control-agency'),
            'id'                => 'testimonials_group',
            'type'              => 'group',
            'clone'             => true,
            'clone_default'     => true,
            'collapsible'   => true,
            'default_state'   => 'collapsed',
            'group_title'   => '{#}. {name} - {designation}',
            'max_clone'         => 10,
            'add_button'        => __( 'Add more testimonial', 'control-agency' ),
            'std'               => [
                [                    
                    'title' => 'Outstanding support team!!',
                    'ratings' => '5',                    
                    'desc' => 'Your design is simply outstanding! From the moment we contacted your team, we were impressed with their expertise and responsiveness. They took the time to understand our needs and delivered a design that truly captured the essence of our brand. The attention to detail and the level of creativity demonstrated by your team was remarkable.',
                    'name' => 'Russell Otten',
                    'designation' => 'Bank of America',
                    'image' => control_agency_file_uri('assets/images/testimonials/1.jpg'),
                    'number' => '',
                    'class' => '',
                ],
                [                    
                    'title' => 'User focused design',
                    'ratings' => '4.5',                    
                    'desc' => 'Your design is simply outstanding! From the moment we contacted your team, we were impressed with their expertise and responsiveness. They took the time to understand our needs and delivered a design that truly captured the essence of our brand. The attention to detail and the level of creativity demonstrated by your team was remarkable.',
                    'name' => 'Russell Otten',
                    'designation' => 'Chief Product manager',
                    'image' => control_agency_file_uri('assets/images/testimonials/2.jpg'),
                    'number' => '',
                    'class' => '',
                ],
                [                    
                    'title' => 'Marketing solutions',
                    'ratings' => '5',                    
                    'desc' => 'Your design is simply outstanding! From the moment we contacted your team, we were impressed with their expertise and responsiveness. They took the time to understand our needs and delivered a design that truly captured the essence of our brand. The attention to detail and the level of creativity demonstrated by your team was remarkable.',
                    'name' => 'Marisol19',
                    'designation' => 'App developer',
                    'image' => control_agency_file_uri('assets/images/testimonials/3.jpg'),
                    'number' => '',
                    'class' => '',
                ],
            ],
            'fields'            => [  
                [
                    'name'        => esc_attr__('Title', 'control-agency'),
                    'id'          => 'title',
                    'desc'        => esc_attr__('Type Client Testimonial title', 'control-agency'),
                    'type'        => 'text',                         
                ],
                [
                    'name'        => esc_attr__('Ratings', 'control-agency'),
                    'id'          => 'ratings',
                    'desc'        => esc_attr__('Add a rating number out of 5', 'control-agency'),
                    'type'        => 'number',                         
                    'min'        => '1',                         
                    'step'        => '.5',                         
                    'max'        => '5',                         
                ],              
                [
                    'name'        => esc_attr__('Testimonial:', 'control-agency'),
                    'id'          => 'desc',
                    'desc'        => esc_attr__('Type Client Testimonial Description', 'control-agency'),
                    'type'        => 'textarea',
                    'placeholder' => esc_attr__('Write in details',   'control-agency'), 
                         
                ],
                [
                    'name'        => esc_attr__('Name:', 'control-agency'),
                    'id'          => 'name',
                    'desc'        => esc_attr__('Type Client\'s Name', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('Guy Hawkins',   'control-agency'), 
                           
                ],
                [
                    'name'        => esc_attr__('Department:', 'control-agency'),
                    'id'          => 'designation',
                    'desc'        => esc_attr__('Type Client Department', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('Bank of America',   'control-agency'), 
                            
                ],
                [
                    'id'               => 'image',
                    'name'             => esc_attr__('Image:',  'control-agency'),
                    'type'             => 'file_input',
                    'desc'             => esc_attr__('Add Client\'s image', 'control-agency'), 
                ], 
                [
                    'name'        => esc_attr__('Count(optional)', 'control-agency'),
                    'id'          => 'number',
                    'desc'        => esc_attr__('Type Counter Text', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('e.g. 01',   'control-agency'), 
                         
                ],         
            ],
        ],       
                   
    ],
];