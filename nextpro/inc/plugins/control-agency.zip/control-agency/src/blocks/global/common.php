<?php 
return [                   
    [
        'id' => 'css_class',
        'type' => 'text',
        'name' => esc_attr__('CSS class', 'control-agency')
    ],
    [
        'id' => 'css_id',
        'type' => 'text',
        'name' => esc_attr__('CSS ID', 'control-agency')
    ],
];