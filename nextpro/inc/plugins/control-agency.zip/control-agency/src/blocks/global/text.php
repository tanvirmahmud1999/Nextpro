<?php
extract(wp_parse_args($args, [
    'name'        => '',
    'id'          => '',
    'desc'        => '',
    'type'        => 'text',
    'std'         => 'Control Agency',
    'placeholder' => '', 
    'tag' => 'p',   
    'attributes' => [],   
]));
return [
    'name'        => esc_attr__('Name', 'control-agency'),
    'id'          => 'name',
    'desc'        => esc_attr__('Type your section name here', 'control-agency'),
    'type'        => 'text',
    'std'         => 'Control Agency',
    'placeholder' => esc_attr__('Section name...',   'control-agency'),  
    'tag' => 'p',       
    'attributes' => [
        'class' => '',
        'id' => '',
        'link' => false,
    ],       
];