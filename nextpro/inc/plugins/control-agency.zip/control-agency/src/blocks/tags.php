<?php 
return [
    'title'           => 'Tags cloud',
    'id'              => 'tags',
    'icon'            => 'tag',
    'description'     => 'Display tags cloud',     
    'fields'          => [
        [
            
            'type' => 'hidden',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'blocks/tags.php',
            'options' => [
                'blocks/tags.php' => 'Tags cloud',
            ]
        ],        
        [
            'name'        => esc_attr__('Custom Tags', 'control-agency'),
            'id'          => 'tags',
            'desc'        => esc_attr__('Enter tags', 'control-agency'),
            'type'        => 'text',
            'clone'       => 'true',
            'std'        =>  ['Digital Marketing', 'UX/UI Design', 'Social Media'],
        ],
        
    ],
];
