<?php 
return [
    'title'           => esc_attr__('Section title', 'control-agency'),
    'id'              => 'section-title',
    'icon'            => 'heading',
    'description'     => 'Display section name, title, subtitle & buttons.',    
    'fields'          => [
        [           
            'type'  => 'hidden',
            'id'    => 'template',
            'name'    => 'Template',
            'std'   => 'components/section-title.php',           
        ],
        [
            'name'        => esc_attr__('Name', 'control-agency'),
            'id'          => 'name',
            'desc'        => esc_attr__('Type your section name here', 'control-agency'),
            'type'        => 'text',
            'std'         => 'Control Agency',
            'placeholder' => esc_attr__('Section name...',   'control-agency'),          
        ],
        [
            'name'        => esc_attr__('Title', 'control-agency'),
            'id'          => 'title',
            'desc'        => esc_attr__('Optional. Leave blank to avoid this field', 'control-agency'),
            'type'        => 'textarea',
            'std'         => sprintf('Welcome to {%s}', get_bloginfo('name')),
            'placeholder' => esc_attr__('Section title...',   'control-agency'),          
        ],
        [
            'name'        => esc_attr__('Subtitle', 'control-agency'),
            'id'          => 'subtitle',
            'type'        => 'textarea',
            'std'         => '{Control Agency} is loved and trusted by thousands of users, Boost your online visibility and reach a wider audience by implementing strategic techniques to optimize your website for top-notch performance on search engines.',
            'placeholder' => esc_attr__('Section subtitle here...',   'control-agency'),          
        ],
        [
            'name'        => 'Enable section button',
            'id'          => 'enable_section_title_button',
            'type'        => 'checkbox',
            'std'         => false,
        ],
        [
            'name' => esc_attr__( 'Section buttons', 'control-agency' ),
            'id'   => 'buttons',
            'type' => 'group',
            'clone' => true,
            'max_clone' => 2,
            'collapsible' => true,
            'default_state' => 'collapsed',
            'group_title' => '{#}. {btn_title}',
            'visible' => ['enable_section_title_button', '=', true],
            'std'   => [
                [
                    'btn_title' => 'View all Reviews',
                    'btn_url' => '#',
                    'btn_class' => 'btn btn-outline-primary'
                ],
            ],
            'fields'  => [
                [
                    'name'        => esc_attr__('Button Text:', 'control-agency'),
                    'id'          => 'btn_title',
                    'desc'        => esc_attr__('Edit Button Text', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('Enter button text...', 'control-agency'),                    
                ],
                [
                    'name'        => esc_attr__('Button URL:', 'control-agency'),
                    'id'          => 'btn_url',
                    'desc'        => esc_attr__('URL for the button', 'control-agency'),
                    'type'        => 'text',
                    'placeholder' => esc_attr__('https://', 'control-agency'), 
                             
                ],
                [
                    'name'        => esc_attr__('Target', 'control-agency'),
                    'id'          => 'btn_target',
                    'type'        => 'select',
                    'std'         => '',
                    'options'    => [
                        '' => 'Open in same window',
                        '_blank' => 'Open in new window',
                    ],
                             
                ],
                [
                    'name'        => esc_attr__('CSS class', 'control-agency'),
                    'id'          => 'btn_class',
                    'type'        => 'text',
                    'std'         => '',
                             
                ],
            ],
           
        ]            
                   
    ]
];