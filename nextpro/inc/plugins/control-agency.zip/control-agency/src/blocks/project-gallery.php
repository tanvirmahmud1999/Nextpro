<?php 
return [
    'title'           => 'Image Gallery',
    'id'              => 'project-gallery',
    'icon'            => 'format-gallery',
    'description'     => 'Display project gallery',
    'fields'          => [
        [            
            'type' => 'select',
            'id' => 'template',
            'name' => 'Template',
            'std' => 'project/single/media-isotope.php',
            'options' => [
                'project/single/media-isotope.php' => 'Isotope grid',
                'project/single/media-carousel.php' => 'Carousel',
            ] 
        ],
        [
            'id'               => 'gallery',
            'name'             => esc_attr__('Gallery images', 'control-agency'),
            'desc'             => esc_attr__('Used for single project gallery inmages in content', 'control-agency'),
            'type'             => 'image_advanced',
            'force_delete'     => false,
            'max_file_uploads' => 6,
            'max_status'       => true,
            'image_size'       => 'thumbnail',
        ],       
        [
            'type'  => 'textarea',
            'id'    => 'gallery_desc',
            'name' => esc_attr('Banner Description', 'neuron'),
            'std' => 'Et blanditiis quae ab porro debitis quo optio fugiat et rerum quod qui incidunt omnis ut impedit dignissimos aut explicabo veniam. Id placeat eveniet a reiciendis inventore ut facere repellendus. Qui tempora magnam et tempora sapiente qui vero cupiditate et maxime iusto ut nobis earum et voluptatem maiores est dolores veniam',
        ],
      
                
    ],
];