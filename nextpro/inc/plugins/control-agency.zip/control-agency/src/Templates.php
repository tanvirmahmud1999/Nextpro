<?php
namespace ControlAgency;

final class Templates{
    
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {     
        add_action('control_agency_content_before', [$this, 'content_before'], -1);
        add_action('control_agency_content_after', [$this, 'content_after'], 9999);

        add_action('control_agency_archive_loop_start', [$this, 'loop_start'], -1);
        add_action('control_agency_archive_loop_end', [$this, 'loop_end'], 999);

		add_action('control_agency_archive_loop_content', [$this, 'loop_content']);		

		// Single page
		add_action('control_agency_single_loop_start', [$this, 'loop_start'], -1);
		add_action('control_agency_single_loop_end', [$this, 'loop_end'], 999);

		add_action('control_agency_single_loop_content', [$this, 'loop_content']);
		
	}   

	public function content_before(){

		$directory = is_singular()? 'single' : 'loop';	
		control_agency_template_part("{$directory}/before", $this->template_part_name());	
		global $control_agency_post_type_content;
		if( is_post_type_archive() && array_key_first($control_agency_post_type_content) != 'content-page'){
			control_agency_template_part("{$directory}/banner", $this->template_part_name());	
		}
		if(is_tax()){
			control_agency_template_part("{$directory}/banner", $this->template_part_name());
		}

		if(is_singular()){
			$this->render_meta_sections();
		}
	}

	public function content_after(){
		$directory = is_singular()? 'single' : 'loop';		
		control_agency_template_part("{$directory}/call-to-action", $this->template_part_name());	
		control_agency_template_part("{$directory}/after", $this->template_part_name());
	}

	public function loop_start(){
		
		$GLOBALS['control_agency_counter'] = 0;
		$GLOBALS['control_agency_isotope'] = true; 
		$directory = is_singular()? 'single' : 'loop';		
		control_agency_template_part("{$directory}/start", $this->template_part_name());		
	}

	public function loop_end(){
		global $control_agency_counter;
		$directory = is_singular()? 'single' : 'loop';
		control_agency_template_part("{$directory}/end", $this->template_part_name());	
		$GLOBALS['control_agency_counter'] = 0;
		$GLOBALS['control_agency_isotope'] = false;		
	}

	public function loop_content(){
		global $control_agency_counter;
		if(!is_singular()){
			control_agency_template_part("loop/content", $this->template_part_name());
		}	
		$control_agency_counter++;	
		
	}

	private function template_part_name(){
		global $controlAgency;
		$name = array_flip($controlAgency->post_types)[get_post_type()];	
		return $name;
	}
	
    private function render_meta_sections(){
		global $controlAgency;
	
		$sections = control_agency_post_type_option('single_template', []);
		if(empty($sections)) return;
		foreach ($sections as $section) {
			if(empty($section['template'])) continue;
			
			$section_key = $section['template'];
            $section_id = $controlAgency->sections[$section_key]; 
			$defaults = !empty($controlAgency->std[$section_id])? $controlAgency->std[$section_id] : [];
			if(empty($defaults)) continue;
			
			$this->single_meta_section($section_id, $defaults);		
		}
		
	}

	private function single_meta_section($section_id, $defaults = []){
		$enabled = get_post_meta(get_the_ID(), "enable_{$section_id}", true);
		if(empty($enabled)) return;
		
		$args = get_post_meta(get_the_ID(), $section_id, true);
		$args = wp_parse_args($args, $defaults);
		
		if(!empty($args['template'])){
			$template_file = $args['template'];
		}elseif(!empty($args['template_file'])){
			$template_file = $args['template_file'];
		}

		if(empty($template_file)) return;
		
		control_agency_render_template($template_file, $args);
	}
}