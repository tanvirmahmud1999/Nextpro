<?php
namespace ControlAgency;

class Elementor_Field{
   
    public $args = [];
    public $data = [];
    public $is_group_field = false;

	public function __construct($args) {	
		$this->args = $args;	
		$this->data = $this->field($args);
	}

    public function __set($name, $value){
        $this->data[$name] = $value;
    }

	public function __get($name){
        if(isset($this->data[$name])) {
			return $this->data[$name];
        }
    }

	
    private function field($args, $defaults = [] ){
		$field = [
			'name' => !empty($args['id'])? $args['id'] : '',			
			'type' => $this->field_type($args['type']),
			'label' => !empty($args['name'])? $args['name'] : '',
			'placeholder' => !empty($args['placeholder'])? $args['placeholder'] : '',
			'description' => !empty($args['desc'])? $args['desc'] : '',			
			'show_label' => true,
			'label_block' => true,
		];
		
		if(!empty($args['std'])){
			$field['default'] = $this->field_default_by_type($args['std'], $args['type']);
		}

		if(!empty($args['visible'])){
			$field['conditions'] = $this->field_condition($args['visible']);
		}

		if(!empty($defaults) && !empty($defaults[$args['id']])){
			$field['default'] = $defaults[$args['id']];
		}
		
		$field = $this->attributes_by_type($field, $args);
		

		return $field;
	}

	private function attributes_by_type($field, $args){
		$type = $args['type'];
		switch ($type) {
			case 'group':				
				$field['separator'] = 'before';	
				$group_title = str_replace(['{#}', ', ', ': ', '. '], '', $args['group_title']);
				$group_title = str_replace(['{', '}'], ['{{{ ', ' }}}'], $group_title);	
				$field['title_field'] = $group_title;	
				$defaults = !empty($field['default'][0])? $field['default'][0] : '';	
				$field['fields'] = array_values($this->repater_fields($args['fields'], $defaults));	
				break;

			case 'checkbox':
				$field['label_block'] = false;
				break;	

			case 'file_input':
				$field['ai'] = ['active' => false];
				break;	

			case 'text':
				if($this->is_group_field){
					$field['ai'] = ['active' => false];
				}				
				break;
			
			case 'number':
				$field['label_block'] = false;
				$field['min'] = !empty($args['min'])? $args['min'] : 0;
				$field['max'] = !empty($args['max'])? $args['max'] : 999;
				$field['step'] = !empty($args['step'])? $args['step'] : 1;
							
				break;	
			
			default:
				
				break;
		}
		return $field;
	}

	private function repater_fields($fields, $defaults){
		$this->is_group_field = true;

		foreach ($fields as $key => $args) {				
			$fields[$key] = $this->field($args, $defaults);				
		}	

		$this->is_group_field = false;

		return $fields;
	}

	private function field_type($type){
		
		switch ($type) {	
			case 'hidden':
				$type = \Elementor\Controls_Manager::HIDDEN;
				break;

			case 'text':
				$type = \Elementor\Controls_Manager::TEXT;
				break;

			case 'number':
				$type = \Elementor\Controls_Manager::NUMBER;
				break;		

			case 'textarea':
				$type = \Elementor\Controls_Manager::TEXTAREA;
				break;
			
			case 'select':
				$type = \Elementor\Controls_Manager::SELECT;
				break;

			case 'single_image':
				$type = \Elementor\Controls_Manager::MEDIA;
				break;

			case 'file_input':
				$type = \Elementor\Controls_Manager::TEXT;
				break;	
			
			case 'checkbox':
				$type = 'switcher';
				break;
			
			case 'group':
				$type = 'repeater';
				break;
			
			default:
				$type = \Elementor\Controls_Manager::RAW_HTML;
				break;
		}

		return $type;
	}

	private function field_default_by_type($std, $type){
		
		switch ($type) {
			case 'group':
				$std = is_array($std[0])? $std : [$std];
				break;

			case 'file_input':
				$std = esc_url($std);
				break;	
			
			default:
				$std = is_array($std)? implode("  \n", $std) : $std;
				break;
		}

		return $std;
	}

	private function field_condition($value){
		$conditions = [];
		if(!empty($value) && is_array($value) && is_string($value[0])){
			$item_name = $value[0];
			$item_operator = $value[1];
			switch ($item_operator) {
				case '!=':
					$item_operator = '!==';
					break;
				
				default:
					$item_operator = '==';
					break;
			}
			
			$item_value = !empty($value[2])? $value[2] : '';

			if(is_bool($item_value)){
				$item_value =  $item_value? 'yes' : 'no';
			}
			
			
			$conditions['terms'][] = [
				'name' => $item_name,
				'operator' => $item_operator,
				'value' => $item_value,
			];
		}
		
		return $conditions;
	}


	
}