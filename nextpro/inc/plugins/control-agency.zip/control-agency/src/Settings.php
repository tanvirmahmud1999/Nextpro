<?php 
namespace ControlAgency;

final class Settings{
    private $id = 'control-agency';
    private $parent = 'options-general.php';
    private $option_name = 'control_agency_options';
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {
		add_filter( 'mb_settings_pages', [$this, 'settings_pages'] );   
        add_action( 'rwmb_meta_boxes', [$this, 'settings_fields'] ); 
        add_filter( 'display_post_states', [$this, 'display_post_states'], 10, 2 );
        add_action( 'mb_settings_page_load', [$this, 'settings_page_load'], 20 );
        add_action( 'mb_settings_page_after_title', [$this, 'settings_page_after_title'] ); 
        add_action( 'mb_settings_page_submit_buttons', [$this, 'settings_page_submit_buttons'] );
                 
	}    
    
    private function check_theme_support(){
        if(current_theme_supports('control-agency')){
            $this->parent = 'themes.php';
        }
        
    }

    private function settings_tabs(){    
        global $controlAgency;    
        $disable_post_types = control_agency_option('disable_post_types', []);
        $tabs = [];
        foreach ($controlAgency->settings_tabs as $post_type => $value) {
            if(in_array($post_type, $disable_post_types)) continue;
            $tabs[$post_type] = $value;
        }
        $controlAgency->settings_tabs = $tabs;
        return $tabs;
        
    }

    public function settings_pages($settings_pages){
        $this->check_theme_support();
        $settings_pages[] = [
            'menu_title'  => __( 'Control Agency', 'control-agency' ),
            'page_title' => __( 'Control Agency Settings', 'control-agency' ),
            'id'          => $this->id,
            'option_name' => $this->option_name,
            'position'    => 25,
            'parent'      => $this->parent,
            'style'       => 'no-boxes',
            'columns'     => 2,
            'customizer'  => true,
            'class'       => $this->id .'-settings-page',
            'tabs'        => $this->settings_tabs(),
            'icon_url'    => 'dashicons-welcome-widgets-menus',
        ];
        return $settings_pages;
    }

    public function settings_tab_fields($tab){ 
		global $controlAgency;           
        $fields = [];
		 
		if(in_array($tab, $controlAgency->post_types)){ 
			$post_type = $tab;
			$args = $controlAgency->{$post_type};
			if(empty($args['has_archive'])) return $fields;
			$fields  =   include __DIR__ ."/settings/post-type.php";
		}else{
			$file ="settings/{$tab}.php";
			$fields  =  Helper::include_admin_file($file);
		}       
        return $fields;        
    }

    public function settings_fields($meta_boxes){        
        global $controlAgency;
        
        foreach ($controlAgency->settings_tabs as $tab => $value) {  
            $meta_boxes[] = [
                'id'             => $tab,
                'title'          => !empty($value['label'])? $value['label'] : $value,
                'settings_pages' => $this->id,
                'context'        => 'normal',
                'class'        => 'control-agency-settings-panel',
                'default_hidden' => true,
                'fields' => $this->settings_tab_fields($tab),
                'tab' => $tab
            ]; 
                      
        }        
        $meta_boxes = $this->get_sidebar_fields($meta_boxes);
        
        return $meta_boxes;
    }   

    function display_post_states( $post_states, $post ) {
        global $controlAgency;
        
        foreach ($controlAgency->post_types as $key => $post_type) {
            $page_id = control_agency_setting( "{$post_type}_archive_page" );
            if(empty($page_id)) continue;
           
            $args = Helper::include_admin_file("post-types/{$key}.php");
            $post_exists = (new \WP_Query(['post_type' => 'any', 'p'=>$page_id]))->found_posts > 0;
            if($post_exists && $page_id == $post->ID){
                $archive_lavel = !empty($args['labels']['archives'])? $args['labels']['archives'] : ucfirst(str_replace(['control', 'ctrl', '-', '_'], '', $post_type));
                $post_states[] = sprintf(esc_attr_x('%s Page', 'Post type archive page', 'control-agency'), $archive_lavel);			
            }
        } 
                
        return $post_states;
    }

    public function settings_page_submit_buttons(){
        $options = get_option($this->option_name, []);
        if(!empty($options)){
            printf('<a href="#" class="button button-danger controlAgencyReset" data-option_name="%s">%s</a>', $this->option_name, esc_attr__('Reset', 'control-agency') );
        }
        
    }
    

    public function settings_page_load($args){
        if ( $args['id'] === $this->id ) {
            flush_rewrite_rules();
        }
    }

    public function get_sidebar_fields($meta_boxes){     
           
        ob_start();
        control_agency_render_template('admin/settings/sidebar.php');
        $description = ob_get_clean();

        ob_start();
        include __DIR__ .'/about/plugin-info.php';
        $plugin_info = ob_get_clean();

        $meta_boxes[] = array (
            'title' => esc_attr__( 'Help & Support', 'control-agency' ),
            'id' => 'sidebar-support-settings',
            'context' => 'side',	
            'text_domain' => 'control-agency',
            'fields' => array(
                array(
                    'type' => 'custom_html',
                    'std' => '<div class="control-agency-settings-sidebar">'.$description.$plugin_info.'</div>',                        
                )
    
            ),			
            'settings_pages' => $this->id,
        );  
        
        if(defined('PERCHCANVAS_VER')){
            $meta_boxes[] = array (
                'title' => esc_attr__( 'Help & Support', 'control-agency' ),
                'id' => 'element-settings',
                'context' => 'side',	
                'text_domain' => 'control-agency',
                'fields' => array(
                    array(
                        'type' => 'custom_html',
                        'std' => '
                        <div class="control-agency-settings-sidebar">
                        <a class="button primary" data-id="controlAgencyAjax" href="#" data-action="generate_elementor_widget">Generate Elementor Files</a>
                        </div>
                        ',                        
                    )
        
                ),			
                'settings_pages' => $this->id,
            );  
        }

         return $meta_boxes;
    }
    

    public function settings_page_after_title(){
        printf(
            '<div id="control-agency-settings-page-notice" class="notice notice-info"><p><strong>%s</strong> %s</p></div>', 
            esc_attr__('Note:', 'control-agency'),
            sprintf(esc_attr__('If the archive page isn\'t functioning properly, try refreshing the %s. For optimal performance, consider using Pretty permalinks (e.g., Post name, Day and name, etc.). This can enhance the usability and SEO-friendliness of your site.
            ', 'control-agency'), 
            sprintf('<a href="'.admin_url('options-permalink.php').'" target="_blank"><strong>%s</strong></a>', esc_attr__('Permalink Settings', 'control-agency'))),
        ); 
    }

    public static function post_type_tabs(){        
        global $controlAgency;
       
       
        $post_type_tabs = [];       
        foreach ($controlAgency->post_types as $key => $post_type) {            
            $args = $controlAgency->{$post_type};
            $post_type_label = !empty($args['label'])? $args['label'] : ucfirst($key);
            $post_type_tabs[$post_type] = [
                'label' => $post_type_label,
                'icon' => !empty($args['menu_icon'])? $args['menu_icon'] : 'dashicons-admin-settings',
                'menu_position' => !empty($args['menu_position'])? $args['menu_position'] : 999,
            ];
        }
        uasort($post_type_tabs, function ($a, $b) {
            return $a['menu_position'] <=> $b['menu_position'];
        });

        return $post_type_tabs;
    }

       
    
}
