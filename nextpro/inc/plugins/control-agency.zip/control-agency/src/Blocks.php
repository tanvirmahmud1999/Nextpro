<?php

namespace ControlAgency;

final class Blocks{
    private $block_prefix = 'control-agency-';
    private $category_title = 'Control Agency';
    private $category_slug = 'control-agency';

    /**
     * Add hooks when module is loaded.
     */
    public function __construct(){
        add_filter('block_categories_all', [$this, 'category']);
        add_action('rwmb_meta_boxes', [$this, 'set_blocks']);
    }

    public function category($categories){
        // Adding a new category.
        $categories[] = array(
            'slug'  => $this->category_slug,
            'title' => $this->category_title
        );

        return $categories;
    }

    public function set_blocks($blocks){
        global $controlAgency;
        $blocks = $controlAgency->sections;
        
        if (!empty($blocks)) {            
            foreach ($blocks as $block_id => $section_id) {                
                $block = $controlAgency->{$section_id};
                if(!empty($block['disable_block'])) continue;
                
                $blocks[] = $this->set_block($block_id, $section_id, $block);
            }
        }

        return $blocks;
    }


    private function set_block($block_id, $section_id, $block){
        global $controlAgency;
        $preview = !empty($controlAgency->std[$section_id])? $controlAgency->std[$section_id] : [];
        $configuration = [
            'type'            => 'block',
            'category'        => 'control-agency',
            'context'         => !empty($block['context'])? $block['context'] : 'normal',
            'render_callback' => 'control_agency_render_block_template',
            'preview' => $preview,
            'supports' => [
                'align' => false,
                'customClassName' => true,
                'anchor' => false
            ],
        ]; 
        $block['id'] = $this->block_prefix . $block_id;
        $block['description'] = !empty($block['description'])? esc_html($block['description']) : '';

        return array_merge($configuration, $block);
    }  
    
    public static function get_blocks_options($post_type=''){
        $options = [];
        $type = str_replace(['control', 'ctrl', '-', '_'], '', $post_type);
        $function_name = "control_agency_get_{$type}_blocks_options";

        if(function_exists($function_name)){
            $_options = call_user_func($function_name);
            if(!is_wp_error($_options) && is_array($_options)){
                $options = $_options;
            }
        }
        // elements      
        foreach (Helper::admin_files('blocks') as $filename) {
            $_section_fields = include Helper::admin_filename($filename);
            if (!is_array($_section_fields) || empty($_section_fields['id'])) continue;
            $options[$_section_fields['id']] = !empty($_section_fields['title']) ? $_section_fields['title'] : 'Untitled';
        }

        return $options;
    }

    public static function get_blocks_std($post_type){
        $std = [];
        $type = str_replace(['control', 'ctrl', '-', '_'], '', $post_type);
        $function_name = "control_agency_get_{$type}_blocks_std";
        
        if(function_exists($function_name)){
            $_std = call_user_func($function_name);
            if(!is_wp_error($_std) && is_array($_std)){
                $std = $_std;
            }
        }else{
            $std = apply_filters($function_name, $std);
        }
        return $std;
    }

}