<?php
namespace ControlAgency;

final class Taxonomies{
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {        
		add_action( 'init', [$this, 'register_taxonomies'], 10 ); 
	}

    public function register_taxonomies(){
        global $controlAgency;  
        
        foreach ($controlAgency->taxonomies as $taxonomy ) {            
            if(!empty($controlAgency->taxonomies__post_type[$taxonomy])){                
                register_taxonomy( $taxonomy, $controlAgency->taxonomies__post_type[$taxonomy], $controlAgency->{$taxonomy} );
            }            
        }
        
    }
    
    public function register_taxonomy_meta_boxes($meta_boxes){
        $meta_boxes[] = include __DIR__ ."/taxonomies/category-meta.php";
        return $meta_boxes;
    }
}