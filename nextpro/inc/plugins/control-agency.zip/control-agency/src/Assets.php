<?php
namespace ControlAgency;

final class Assets{
    private $version = CTRL_AGENCY_VER;
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {  
        $this->version .= WP_DEBUG? '-'.time() : '';      
		add_action( 'admin_enqueue_scripts', [$this, 'admin_enqueue_scripts'] ); 
		add_action( 'wp_enqueue_scripts', [$this, 'enqueue_scripts'] ); 
	}

    public function enqueue_scripts(){
        wp_enqueue_script( 'control-agency-animation', control_agency_file_uri('assets/js/animation.js'), false, $this->version, false );
        wp_enqueue_script( 'control-agency-scripts', control_agency_file_uri('assets/js/scripts.js'), false, $this->version, false );
        wp_enqueue_style( 'control-agency-animation', control_agency_file_uri('assets/css/animation.css'), false, $this->version, 'all' );
        wp_enqueue_style( 'control-agency-style', control_agency_file_uri('assets/css/style.css'), false, $this->version, 'all' );
    }

    public function admin_enqueue_scripts($hook){
      

        if ( 'edit.php' == $hook ) {
            wp_enqueue_style( 'control-agency-edit', CTRL_AGENCY_ASSETS.'css/style.css', false, $this->version );
        }

        wp_enqueue_style( 'control-agency-admin-style', CTRL_AGENCY_ASSETS.'css/admin-style.css', false, $this->version );
        wp_enqueue_script( 'control-agency-admin', CTRL_AGENCY_ASSETS.'js/admin.js', ['jquery'], $this->version );
		$l10n = [
			'ajax' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce('controlAgency'),
		];
		wp_localize_script( 'control-agency-admin', 'controlAgencyAdmin', $l10n );
        
    }

   
}