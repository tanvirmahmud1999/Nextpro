<?php
return [
    [
        'id' => "disable_post_types",
        'name' => esc_attr__('Disable Post Types', 'control-agency'),
        'type' => 'checkbox_list',  
        'inline'          => false,
        'select_all_none' => false,    
        'options' => [
            'controlproject'       => 'Projects',
            'controlservice' => 'Services',
            'controlmember'        => 'Team',
            'controljob'     => 'Jobs'
        ], 
        'std' => [],
    ],
];
