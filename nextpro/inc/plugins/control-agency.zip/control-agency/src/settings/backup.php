<?php
return [
    [
        'name' => esc_attr__('Backup', 'control-agency'),
        'type' => 'backup',  
    ],
   
];
