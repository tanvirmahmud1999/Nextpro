<?php

use ControlAgency\Blocks;
use ControlAgency\Helper;
global $controlAgency;
$args = $controlAgency->{$post_type};
$post_type_label = !empty($args['label']) ? $args['label'] : ucfirst(str_replace(['control', 'ctrl', '-', '_'], '', $post_type));

$fields = [
    [
        'desc' => '<h3>' . $post_type_label . ' Settings</h3><hr />',
        'type' => 'custom_html',
    ],
    [
        'id' => "{$post_type}_archive_page",
        'name' => esc_attr__('Archive Page', 'control-agency'),
        'type' => 'post',
        'post_type' => 'page',
        'field_type' => 'select_advanced',
        'placeholder' => esc_attr__('Choose a page', 'control-agency'),
        'desc' => sprintf(esc_attr__('Customize the appearance and information of your %s archive page to improve navigation and user experience.', 'control-agency'), '<strong>' . $args['label'] . '</strong>'),
        'query_args' => array(
            'post_status' => 'publish',
            'posts_per_page' => - 1,
        ),
    ],
    [
        'id' => "{$post_type}_permalink_structure",
        'name' => esc_attr__('Permalink Settings', 'control-agency'),
        'type' => 'custom_html',
        'desc' => 'WordPress Control Agency Plugin offers you the ability to create a custom URL structure for your <code>' . $args['label'] . '</code> permalinks and archives. Custom URL structures can improve the aesthetics, usability, and forward-compatibility of your links.',
    ],
    [
        'name' => sprintf(esc_attr__('%s archive base(slug)', 'control-agency'), $args['label']),
        'type' => 'custom_html',
        'desc' => Helper::archive_page_help($post_type, $args),
        'visible' => ["{$post_type}_archive_page", '!=', '']
    ],
    [
        'id' => "{$post_type}_archive_page_title",
        'name' => esc_attr__('Archive Title', 'control-agency'),
        'type' => 'text',
        'size' => 60,
        'std' => !empty($args['labels']['name']) ? $args['labels']['name'] : '',
    ],
    [
        'id' => "{$post_type}_archive_page_desc",
        'name' => esc_attr__('Archive Description', 'control-agency'),
        'type' => 'textarea',
        'size' => 60,
        'std' => !empty($args['description']) ? $args['description'] : '',
    ],
    [
        'id' => "{$post_type}_read_more_text",
        'name' => esc_attr__('Read More Text', 'control-agency'),
        'type' => 'text',
        'placeholder' => 'Read more',
        'desc' => 'e.g. Read more, Discover',
        'size' => 40,
        'std' => '',
    ],
    [
        'id' => "{$post_type}_archive_query",
        'name' => esc_attr__('Archive Query', 'control-agency'),
        'type' => 'query',           
        'post_type' => $post_type,
        'std' => [
            'post_type' => $post_type,
            'posts_per_page' => 5,
        ],
    ],    
    [
        'name' => esc_attr__('Archive Template', 'control-agency'),
        'label_description' => sprintf(__('Organize sections for %s archive page.', 'control-agency'), $args['label']),
        'id' => "{$post_type}_archive_template",
        'type' => 'group',
        'clone' => true,
        'clone_default' => true,
        'clone_as_multiple' => true,
        'collapsible' => true,
        'default' => true,
        'sort_clone' => true,
        'default_state' => 'collapsed',
        'group_title' => '{#}. {template}',
        'max_clone' => 2,
        'add_button' => __('Add New Section', 'control-agency'),        
        'visible' => ["{$post_type}_archive_page", '!=', ''],
        'std' => [
            [
                'template' => 'content-archive',
            ],
            [
                'template' => 'content-page',
            ]
        ],
        'fields' => [            
            [                
                'id' => 'template',
                'placeholder' => esc_attr__('choose a template', 'control-agency'),
                'type' => 'select',
                'options' => [
                    'content-archive' => 'Archive content',
                    'content-page' => 'Page content'
                ],
            ]
        ],
    ],
    [
        'name' => esc_attr__('Single Template Sections', 'control-agency'),
        'label_description' => sprintf(__('Organize sections for %s single page.', 'control-agency'), $args['label']),
        'id' => "{$post_type}_single_template",
        'type' => 'group',
        'clone' => true,
        'clone_default' => true,
        'clone_as_multiple' => true,
        'collapsible' => true,
        'sort_clone' => true,
        'default' => true,
        'default_state' => 'collapsed',
        'group_title' => '{#}. {name}: {template}',
        'max_clone' => 10,
        'add_button' => __('Add New Section', 'control-agency'),
        'std' => Blocks::get_blocks_std($post_type),
        'fields' => [
            [
                'name' => esc_attr__('Section Name', 'control-agency'),
                'id' => 'name',
                'desc' => sprintf(esc_attr__('Display in %s post type data', 'control-agency'), $post_type),
                'type' => 'text',
                'placeholder' => esc_attr__('e.g. Banner', 'control-agency'),
            ],
            [
                'name' => esc_attr__('Section', 'control-agency'),
                'id' => 'template',
                'desc' => esc_attr__('choose a template', 'control-agency'),
                'type' => 'select_advanced',
                'options' => Blocks::get_blocks_options($post_type),
            ]
        ],
    ],
    [
        'id' => "{$post_type}_custom_query",
        'name' => esc_attr__('Custom Query', 'control-agency'),
        'type' => 'group',           
        'clone' => true,
        'clone_default' => true,
        'clone_as_multiple' => true,
        'collapsible' => true,
        'default' => true,
        'sort_clone' => false,
        'default_state' => 'collapsed',
        'group_title' => '{#}. {title}',
        'add_button' => __('Add New Query', 'control-agency'),
        'label_description' => sprintf(__('Create WP Query for template.', 'control-agency'), $args['label']),
        'std' => [
            [
                'title' => sprintf('Recent %s', $args['label']),
                'query' => [
                    'post_type' => $post_type,
                    'posts_per_page' => 5,
                ]
            ]
        ],
        'fields' => [
            [
                'name' => esc_attr__('Title', 'control-agency'),
                'id' => 'title',
                'desc' => sprintf(esc_attr__('Add Query title for %s, basicall used in page.', 'control-agency'), $args['label']),
                'type' => 'text',
                'placeholder' => sprintf(esc_attr__('e.g. Featured %s', 'control-agency'), $args['label']),
            ],
            [
                'id' => "query",
                'name' => esc_attr__('WP Query', 'control-agency'),
                'type' => 'query',           
                'post_type' => $post_type
            ],
        ]
    ],
    [
        'id' => "{$post_type}_archive_page_slug",
        'name' => sprintf(esc_attr__('%s archive base(slug)', 'control-agency'), $args['label']),
        'type' => 'text',
        'size' => '20',
        'class' => 'field-slug',
        'prepend' => '<code>' . get_site_url() . '/</code>',
        'std' => is_string($args['has_archive']) ? $args['has_archive'] : '',
        'visible' => ["{$post_type}_archive_page", '=', '']
    ],
    [
        'id' => "{$post_type}_single_page_slug",
        'name' => sprintf(esc_attr__('%s single base(slug)', 'control-agency'), $args['label']),
        'type' => 'text',
        'size' => '20',
        'class' => 'field-slug',
        'prepend' => '<code>' . get_site_url() . '/</code>',
        'std' => !empty($args['rewrite']['slug']) ? $args['rewrite']['slug'] : str_replace(['control', 'ctrl', '-', '_'], '', $post_type),
    ],
    
];

// Taxonomies slug
if (in_array($post_type, $controlAgency->taxonomies__post_type)) {
    $fields[] = [
        'id' => "{$post_type}_taxonomy_base",
        'name' => esc_attr__('Taxonomies base', 'control-agency'),
        'type' => 'custom_html',
    ];
    foreach ($controlAgency->taxonomies__post_type as $taxonomy => $tax_post_type) {
        if(($tax_post_type != $post_type)) continue;

        $key = array_flip($controlAgency->taxonomies)[$taxonomy];
        $args = $controlAgency->{$taxonomy};

        $fields[] = [
            'id' => "{$post_type}_{$taxonomy}_slug",
            'name' => sprintf(esc_attr__('%s base(slug)', 'control-agency'), $args['label']),
            'type' => 'text',
            'size' => '20',
            'class' => 'field-slug',
            'prepend' => '<code>' . get_site_url() . '/</code>',
            'std' => !empty($args['rewrite']['slug']) ? $args['rewrite']['slug'] : '',
        ];
    }
}

return $fields;
