<?php
$tabs = [
    'general' => [
        'label' => 'General',
        'icon' => 'dashicons-admin-generic'
    ]
];
$post_type_tabs = ControlAgency\Settings::post_type_tabs();
$tabs = array_merge($tabs, $post_type_tabs);

$tabs['backup'] = [
    'label' => 'Backup & Restore',
    'icon' => 'dashicons-database'
];
return $tabs;
