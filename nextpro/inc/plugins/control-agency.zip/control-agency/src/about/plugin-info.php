<div class="postbox-sidebar" style="display: none!important">
    <div class="postbox-header-sidebar">
        <h2>About Plugin</h2>
    </div>
    <div class="inside">
        <div class="inside-sidebar">
            <p>Thanks for using <strong>Control Agency</strong> plugin!</p>           
            <ul>
                <li>Plugin: Control Agency</li>
                <li>Version: <?php echo CTRL_AGENCY_VER; ?></li>
                <li>Author: <a href="https://themeperch.net" target="_blank">Themeperch</a></li>
                <li>Support: <a href="https://themeperch.net/contact/" target="_blank">Contact our support team</a> for assistance.</li>
            </ul>

            <a href="https://1.envato.market/OrEA2P" target="_blank" class="button">Our Works</a>
            <a href="https://docs.themeperch.net/?item=control-agency" target="_blank" class="button">Documentation</a>
        </div>
    </div>
</div>