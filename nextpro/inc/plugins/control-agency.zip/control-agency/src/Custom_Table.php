<?php
namespace ControlAgency;

final class Custom_Table{

	public static function get_row($name, $table_name="control_agency"){
		global $wpdb;
		$table_name = $wpdb->prefix . $table_name;
		$results = $wpdb->get_row( "SELECT * FROM $table_name WHERE name='{$name}'", ARRAY_A );
		return $results;
	}

	public static function exists($name, $table_name="control_agency"){
		global $wpdb;
		$table_name = $wpdb->prefix . $table_name;
		$results = $wpdb->get_row( "SELECT * FROM $table_name WHERE name='{$name}'", ARRAY_A );
		if(empty($results) || is_wp_error($results)) return false;

		return true;
	}

	public static function tables(){
		$tables = [
			[
				'table_name' => 'control_agency',
				'mysql' => [
					'name' => 'VARCHAR(200) NOT NULL',
					'value'   => 'longtext NOT NULL',
					'created_at' => 'DATETIME',
					'updated_at' => 'DATETIME',
					'status'     => 'VARCHAR(20)',
				],
				'index' => ['name'],
				'models' => true
			]
		];
		return $tables;
	}
   
}