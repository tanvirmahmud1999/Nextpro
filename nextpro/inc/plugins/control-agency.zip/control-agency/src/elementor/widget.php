<?php
namespace ControlAgency\Elementor;

class CLASSNAME extends \Elementor\Widget_Base{    
	    
    public function get_name() {  
        
		return 'control_agency_WIDGETID';
	}

	public function get_title() {
		return 'WIDGETTITLE';
	}

	public function get_icon() {
		return 'dashicons dashicons-WIDGETICON';
	}

	public function get_categories() {
		return [ 'WIDGETCATEGORY' ];
	}

	public function get_keywords() {
		return explode(' ', 'WIDGETTITLE');      
	}

    protected function register_controls() {

		$this->start_controls_section(
			'control-agency-fields',
			[
				'label' => 'Advanced',
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'widget_id' =>  'WIDGETID',
			]
		);

        $this->add_control(
			'attributes',
			[
				'type' => \Elementor\Controls_Manager::TEXT,
				'label' => esc_html__( 'Attributes', 'control-agency' ),
			]
		);

        $this->end_controls_section();
    }

	protected function render() {
		$settings = $this->get_settings_for_display();
		if(!empty($settings['template'])){
			$template_file = $settings['template'];
		}elseif(!empty($settings['template_file'])){
			$template_file = $settings['template_file'];
		}else{
			$template_file = 'blocks/RENDERFILENAME.php'; 
		}
		control_agency_render_template($template_file, $settings);
	}
    
    
}