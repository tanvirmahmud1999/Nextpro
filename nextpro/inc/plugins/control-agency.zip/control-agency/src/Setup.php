<?php
namespace ControlAgency;

final class Setup{	
    private $post_type_prefix = 'control';
	private $data = array();
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {	
		// 1. initialialize custom tables
		add_action('init', [$this, 'check_tables'], 1);

		// 2. check custom tables
		add_action( 'init', [$this, 'check_status'], 2 );	

		// 3. setup global data
		add_action( 'init', [$this, 'data'], 3 );		
	}	

	public function __set($name, $value){
        $this->data[$name] = $value;
    }

	public function __get($name){
        if(isset($this->data[$name])) {
			return $this->data[$name];
        }
    }

	public function check_tables() {
        global $wpdb;		

        // Check if the 'control_agency' table exists
		foreach (Custom_Table::tables() as $table) {
			extract(wp_parse_args($table, [
				'table_name' => '',
				'mysql' => [],
				'index' => [],
				'models' => false
			]));
			$table_name = $wpdb->prefix . $table_name;
			if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
				$this->create_tables();
			}
		}
        
    }

    private function create_tables(){
		if ( ! current_user_can( 'manage_options' ) && ( ! wp_doing_ajax() ) ) {
			wp_die( __( 'You are not allowed to access this part of the site' ) );
		}

		global $wpdb;
		foreach (Custom_Table::tables() as $table) {
			extract(wp_parse_args($table, [
				'table_name' => '',
				'mysql' => [],
				'index' => [],
				'models' => false
			]));
			
			\MB_Custom_Table_API::create( "{$wpdb->prefix}{$table_name}", $mysql, $index, $models );			
			 
		}
               
    }

	public function check_status(){
		$types = [
			'post_types',
			'taxonomies'			
		];
		foreach ($types as $name) {			
			if ( !Custom_Table::exists($name) ) {			
				$this->set_type($name);
			}
		}		
		
	}

	private function set_type($name){
		
		switch ($name) {
			case 'post_types':				
				$data = [ 
					'name' => $name, 
					'value' => maybe_serialize($this->post_types()), 
					'created_at' => current_time( 'mysql' ), 
					'updated_at' => current_time( 'mysql' ), 
					'status' => 'plugin' 
				];
				$this->insert($data);																
				break;
			
			case 'taxonomies':				
				$data = [ 
					'name' => $name, 
					'value' => maybe_serialize($this->taxonomies()), 
					'created_at' => current_time( 'mysql' ), 
					'updated_at' => current_time( 'mysql' ), 
					'status' => 'plugin' 
				];
				$this->insert($data);																
				break;

			default:
				break;
		}

	}

	private function insert($data, $table_name = NULL){
		global $wpdb;
		if(empty($table_name)){
			$table_name = $wpdb->prefix . 'control_agency';
		}
		$insert_id = $wpdb->insert($table_name, $data);
		if($insert_id){
			return true;
		}else{
			return false;
		}
	}

	private function post_types(){
		$post_types = [];		
		foreach ( Helper::admin_files('post-types') as $filename) {
			$type = str_replace('.php', '', basename($filename));
			$post_type = $this->post_type_prefix.$type;
			$post_types[$type] = $post_type;						
		}
		return apply_filters("control_agency_set_post_types",  $post_types );
	}

	private function taxonomies(){
		$taxonomies = [];		
		foreach ( Helper::admin_files('taxonomies') as $filename) {
			$type = str_replace('.php', '', basename($filename));
			$taxonomy = str_replace('-', '_', $type);
			$taxonomies[$type] = $taxonomy;
		}
		return apply_filters("control_agency_set_taxonomies",  $taxonomies );
	}

	public function data(){
		global $wpdb;
		$table_name = $wpdb->prefix . 'control_agency';
		$results = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );		
		if(!is_wp_error($results) && !empty($results)){
			foreach ($results as $key => $row) {
				$value = maybe_unserialize($row['value']);	
				$type = $row['name'];
				$value = apply_filters("control_agency_set_{$type}",  $value );			
				$this->{$row['name']} = $value;
				$results[$key] = [
					'name' => $row['name'],
					'valye' => $value,
				];
			}
			$this->settings = maybe_unserialize($results);
		}

		// 1. add post type & taxonomy args
		$this->admin_data();
		// 2. add post type & taxonomy relations
		$this->post_type__taxonomies();
		// 3. Settings page tab
		$this->settings_tabs();
		// 4. Settings fields. Load default options
		$this->settings_fields();
		// 5. Set global options
		$this->global_options();
		// 6. Set section, fields, std
		$this->sections();	

	}


	private function admin_data(){		
		foreach ($this->post_types as $filename => $post_type) {
			$args = Helper::include_admin_file("post-types/{$filename}.php");
			$this->{$post_type} = apply_filters("control_agency_set_{$post_type}_args",  $args );
		}
		foreach ($this->taxonomies as $filename => $taxonomy) {
			$args = Helper::include_admin_file("taxonomies/{$filename}.php");
			$this->{$taxonomy} = apply_filters("control_agency_set_{$taxonomy}_args",  $args );
		}		
	}

	private function post_type__taxonomies(){
		$post_type__taxonomies = [];
		$taxonomies__post_type = [];
		foreach ($this->taxonomies as $value => $taxonomy) {
			$arr = explode('-', $value);
			$post_type_key = reset($arr);
			if(!array_key_exists($post_type_key, $this->post_types)) continue;

			$post_type__taxonomies[$post_type_key][] = $taxonomy;	
			$taxonomies__post_type[$taxonomy] = $this->post_types[$post_type_key];		
		}

		$this->post_type__taxonomies = $post_type__taxonomies;
		$this->taxonomies__post_type = $taxonomies__post_type;
		
	}

	private function settings_tabs(){        
        $tabs = Helper::include_admin_file('settings/tabs.php');
		$settings_tabs = [];
		foreach ($tabs as $key => $tab) {
			$key = str_replace([' ', '-'], '_', $key);
			$settings_tabs[$key] = $tab;
		}
		$this->settings_tabs = apply_filters("control_agency_settings_tabs", $settings_tabs);
		
    }	

	private function settings_fields(){ 
		$settings_fields = $options = [];      
        foreach ($this->settings_tabs as $tab => $value) { 
			if(empty($value['label'])) continue;
			
			$type = str_replace(['control', 'control_', '-', ' '], '', $tab);

			$tab_fields = apply_filters("control_agency_settings_{$type}_fields", Helper::settings_tab_fields($tab));
			$fields_std = apply_filters("control_agency_settings_{$type}_fields_std", array_column($tab_fields, 'std', 'id'));

			$settings_fields[$tab] = $tab_fields;
			$options = array_merge($options, $fields_std);
		}
		$this->settings_fields = apply_filters("control_agency_settings_fields", $settings_fields);
		$this->options = apply_filters("control_agency_settings_options_std", $options);
    }

	private function global_options(){
		$options = get_option('control_agency_options', $this->options);
        $GLOBALS['control_agency_options'] = $options;
		$this->globalOptions = $options;
	}
	
	
	private function sections(){
		$sections = $std = $fields = [];
		foreach ( Helper::admin_files('blocks') as $relative_path => $filename) {
			$filename = basename($filename);
			$args = Helper::include_admin_file($relative_path);
			if(empty($args['id'])) continue;
			
			$id = str_replace('-', '_', $args['id']);
			$sections[$args['id']] = $id;			
			$this->{$id} = apply_filters("control_agency_block_{$id}_args", $args);
			
			if(!empty($args['fields'])){
				$fields[$id] = apply_filters("control_agency_block_{$id}_fields", $args['fields']);
				$std[$id] = apply_filters("control_agency_block_{$id}_fields_std", array_column($args['fields'], 'std', 'id'));
			}
		}
		$this->sections = apply_filters("control_agency_block_sections", $sections);
		$this->fields = $fields;
		$this->std = $std;
	}	
	
}