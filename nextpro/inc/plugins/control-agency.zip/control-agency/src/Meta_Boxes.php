<?php
namespace ControlAgency;


final class Meta_Boxes{
   
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {     
        add_action( 'rwmb_meta_boxes', [$this, 'set_meta_boxes'] ); 
	}   

	public function set_meta_boxes($meta_boxes){        
       $meta_boxes = $this->get_post_type_blocks($meta_boxes);
        return $meta_boxes;        
    }

    function get_post_type_blocks($meta_boxes){
        global $controlAgency;

        foreach ($controlAgency->post_types as $post_type) {
            $fields = $this->fields($post_type);
            $args = $controlAgency->{$post_type};
            if(empty($fields)) continue;
            $meta_boxes[] = [
                'title'      => sprintf(esc_attr_x('%s data', 'Post type meta fields title', 'control-agency'), $args['labels']['singular_name']),
                'id'         => 'control-agency-'.$post_type.'-data',
                'class' => 'control-agency-settings-page',
                'priority' => 'low',
                'post_types' => [$post_type],
                'tab_style' => 'left',
                'tabs'=> $this->tabs($post_type),
                'fields'          => $fields
            ];
        }

        return $meta_boxes;
    }

    private function sections($post_type){
        $sections = control_agency_post_type_option('single_template', [], $post_type);
        $type = str_replace(['control', 'control_', '-', ' '], '', $post_type);
        return apply_filters("control_agency_{$type}_sections", $sections);
    }

    private function tabs($post_type){
        global $controlAgency;        
       
        $tabs = [
            'general' => [
                'label' => 'General',
                'icon' => 'dashicons-admin-settings',
            ]
        ];
        
        $sections = $this->sections($post_type);
        foreach ($sections as $section) {            
            if(empty($section['name']) || empty($section['template'])) continue;  

            $section_label = $section['name'];         
            $section_key = $section['template'];

            $section_id = $controlAgency->sections[$section_key];            
            $icon = $controlAgency->{$section_id}['icon'];
            
            $tabs[$section_key] = [
                'label' => $section_label,
                'icon' => !empty($icon)? 'dashicons-'.$icon : 'dashicons-admin-settings',
                'id' => $section_id,
            ];
        }
        return $tabs;
    }

    private function general_template_fields($post_type){
        global $controlAgency;
        $fields = [];
        $type = array_flip($controlAgency->post_types)[$post_type];
        $filename = Helper::admin_filename(__DIR__."/meta-boxes/{$type}.php");
        if(file_exists($filename)){
            $_fields = include $filename;
            if(!is_wp_error($_fields) && is_array($_fields) && is_array(reset($_fields))){
                foreach ($_fields as $key => $field) {
                    $field['tab'] = 'general';
                    $fields[$key] = $field;
                }
            }
        }
        return $fields;
    }

    private function general_fields($fields, $sections, $post_type){
        if(empty($sections)) return $fields;

        global $controlAgency;

        $link = admin_url('options-general.php?page=control-agency');
        if(current_theme_supports('control-agency')){
            $link = admin_url('themes.php?page=control-agency');
        }
        
        $fields[] = [
            'type' => 'custom_html',
            'name' => 'Single template',
            'tab' => 'general',
            'desc' => sprintf(esc_attr__('Single template settings for %s Update single template section settings in %s', 'control-agency'), '<code>'.$controlAgency->{$post_type}['labels']['singular_name'].'</code>.<br />', '<a href="'.esc_url($link).'">Control Agency</a>'),
        ];

        
        foreach ($sections as $section) {
            if(empty($section['name']) || empty($section['template'])) continue; 
            
            $section_label = $section['name'];         
            $section_key = $section['template'];
            $section_id = $controlAgency->sections[$section_key];
            
            $fields[] = [
                'type' => 'checkbox',
                'name' => '&nbsp;',
                'desc' => sprintf(esc_attr__('Display %s section. Checked to enable.', 'control-agency'), '<strong>'.$section_label.'</strong>'),
                'id' => 'enable_'.$section_id,
                'tab' => 'general',
                'std' => true
            ];
        } 

        return $fields;
    }

    

    private function fields($post_type){
        global $controlAgency;
        $sections = $this->sections($post_type);

        $fields = $this->general_template_fields($post_type);        
        $fields = $this->general_fields($fields, $sections, $post_type);

        $type = array_flip($controlAgency->post_types)[$post_type];
        foreach ($sections as $section) {
            if(empty($section['name']) || empty($section['template'])) continue;
        
            $section_key = $section['template'];
            $section_id = $controlAgency->sections[$section_key];                        

            $fields[] = [
                'type' => 'custom_html',
                'desc' => sprintf('<h3 style="margin-top: 0; margin-bottom: 5px;">%1$s settings</h3><p style="margin-top: 0"><em>Note: Do not want to show this section on frontend! uncheck the display option for %1$s in %2$s tab.</em></p><hr />', '<strong>'.$section['name'].'</strong>', '<strong>General</strong>'),
                'tab' => $section_key,
            ];

            $section_fields = apply_filters("control_agency_{$type}_{$section_id}_fields", $controlAgency->{$section_id}['fields']);
            $fields[] = [
                'type' => 'group',
                'id' => $section_id,
                'tab' => $section_key,
                'std' => $this->section_fields_std($section_id, $post_type),
                'fields' => $this->fix_conditions($section_fields, $section_id),
                'clone' => false,
            ];
        }
        
        return $fields;
    }

    private function section_fields_std($section_id, $post_type = ''){
        global $controlAgency;
        $section_fields_std = $controlAgency->std[$section_id];

        $type = str_replace(['control', 'control_', '-', ' '], '', $post_type);
        $function_name = "control_agency_{$type}_{$section_id}_std";
        if(function_exists($function_name)){
            $std = call_user_func("control_agency_{$type}_{$section_id}_std", $section_fields_std);
            $section_fields_std = array_merge($section_fields_std, $std);
        }else{
            $section_fields_std = apply_filters("control_agency_{$type}_{$section_id}_std", $section_fields_std);
        }
        return $section_fields_std;
    }

    private function fix_conditions($fields, $group_id){
        foreach ($fields as $key => $value) {
            if( !empty($value['visible'][0]) && is_string($value['visible'][0]) ){
                $value['visible'][0] = $group_id.'_'.$value['visible'][0];
            }
            if( !empty($value['hidden'][0]) && is_string($value['hidden'][0]) ){
                $value['hidden'][0] = $group_id.'_'.$value['hidden'][0];
            }
            unset($value['std']);
            $fields[$key] = $value;
        }
        return $fields;
    }    
    
}