<?php
namespace ControlAgency;

final class Social_Share{
    
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {     
        add_action( 'customize_register', array( $this, 'register' ), 999 );
		add_action('control_agency_social_share', [$this, 'social_share'], 10, 2);
	}

    /**
	 * Register customizer options.
	 *
	 * @param 	WP_Customize_Manager 	$wp_customize Theme Customizer object.
	 * @return 	void
	 */
	public function register( $wp_customize ) {

		/**
		 * Add Social Share settings to customizer
		 */
		$wp_customize->add_section(
			'social_share',
			array(
				'title'    => esc_html__( 'Social Share Settings', 'neuron' ),
				'priority' => 110,
			)
		); 
		
		$wp_customize->add_setting(
			'display_social_share',
			array(
				'capability'        => 'edit_theme_options',
				'default'           => true,
				'sanitize_callback' => static function ($value) {
					return boolval($value);
				}
			)
		);
		$wp_customize->add_control(
			'display_social_share',
			array(
				'type'    => 'checkbox',
				'section'       => 'social_share',
				'label'         => esc_html__('Enable Social Share', 'control-agency'),
			)
		);	

		// Add a setting for the title
		$wp_customize->add_setting(
			'social_share_title', 
			array(
				'default' => __('Share this article', 'control-agency'),
				'type' => 'theme_mod',
				'capability' => 'edit_theme_options',
				'sanitize_callback' => static function ($value) {
					return esc_attr($value);
				}
			)
		);

		// Add a control for the title
		$wp_customize->add_control(
			'social_share_title', 
			array(
				'label' => __('Social Share Title', 'control-agency'),
				'section' => 'social_share',
				'type' => 'text',
				'active_callback' => static function () {
					return get_theme_mod('display_social_share') ? true : false;
				}
			)
		);

        // Add a setting for the icon type
		$wp_customize->add_setting(
			'social_share_icons', 
			array(
				'type' => 'theme_mod',
				'capability' => 'edit_theme_options',
				'sanitize_callback' => static function ($value) {
					return esc_attr($value);
				}
			)
		);

		// Add a control for the icons type
		$wp_customize->add_control(
			'social_share_icons', 
			array(
				'label' => __('Social Share icons', 'control-agency'),
				'section' => 'social_share',
				'type' => 'select',
                'choices' => [
                    '' => __('Theme default', 'control-agency'),
                    'shortcode' => __('Shortcode', 'control-agency'),
                ],
				'active_callback' => static function () {
					return get_theme_mod('display_social_share') ? true : false;
				}
			)
		);

        // Add a setting for the share shortcode
		$wp_customize->add_setting(
			'social_share_shortcode', 
			array(
				'type' => 'theme_mod',
				'capability' => 'edit_theme_options',
				'sanitize_callback' => static function ($value) {
					return esc_attr($value);
				}
			)
		);

		// Add a control for the icons type
		$wp_customize->add_control(
			'social_share_shortcode', 
			array(
				'label' => __('Social Share shortcode', 'control-agency'),
				'section' => 'social_share',
				'type' => 'textarea',                
				'active_callback' => static function () {
					return (get_theme_mod('display_social_share') && get_theme_mod('social_share_icons') == 'shortcode')? true : false;
				}
			)
		);

		$this->add_partials($wp_customize);
	}


    private function add_partials($wp_customize){

        $wp_customize->selective_refresh->add_partial(
			'social_share_title',
			array(
				'selector'        => '.box-share-post',
			)
		);

      

        return $wp_customize;
    }



    public function social_share($before, $after){   
        if(!get_theme_mod('display_social_share', true)) return;
        $args = [
            'social_share_title' => get_theme_mod('social_share_title', __('Share this article', 'control-agency')),
            'social_share_icons' => get_theme_mod('social_share_icons', ''),
            'social_share_shortcode' => '',
            'icons' => [
                [
                    'id' => 'linkedin', 
                    'title' => 'Linkedin', 
                    'class' => 'icon-linkedin',
                    'url' => add_query_arg(['url' => get_permalink(), 'title' => get_the_title(),'summary' => get_the_excerpt(),  'source' => get_bloginfo('name')], 'https://www.linkedin.com/shareArticle')
                ],
                [
                    'id' => 'pinterest', 
                    'title' => 'Pinterest', 
                    'class' => 'icon-pinterest',
                    'url' => add_query_arg(['url' => get_permalink(), 'description' => get_the_title()], 'https://pinterest.com/pin/create/button')
                ],
                [
                    'id' => 'facebook', 
                    'title' => 'Facebook', 
                    'class' => 'icon-facebook',
                    'url' => add_query_arg('u', get_permalink(), 'http://www.facebook.com/sharer/sharer.php')
                ],              
                
                [
                    'id' => 'x', 
                    'title' => 'Twitter', 
                    'class' => 'icon-twitter',
                    'url' => add_query_arg(['url' => get_permalink(), 'text' => get_the_title(), 'hashtags' => str_replace([' ', '<br />'], '',wp_strip_all_tags(control_agency_get_terms(['separator'=> ',', 'taxonomy' => 'category', 'disable_links' => true ], false)))], 'https://twitter.com/intent/tweet')
                ]
            ]
        ];
        echo $before;        
        control_agency_locate_template('social-share.php', $args);
        echo $after;
    }

    
}