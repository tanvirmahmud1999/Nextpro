<?php
namespace ControlAgency;

final class Ajax{
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {        
		add_action( 'wp_ajax_controlAgencyAjax', [$this, 'do_ajax'] );
	}

    public function do_ajax(){
		if(!wp_verify_nonce( $_POST['nonce'], 'controlAgency' )){
			die( __( 'Security check', 'control-agency' ) ); 
		}
		
		if(empty($_POST['data']['action'])){
			Helper::debug_log($_POST['data']['action']);
			wp_die('Action is missing', 'Button error!!', $_POST['data']);
		}

		$method_name = $_POST['data']['action'];
		
		
		if(!method_exists($this, $method_name)){
			wp_die('Method missing', $method_name, $_POST['data']);
		}
		
		
		call_user_func( [$this, $method_name], $_POST);

		wp_die();
	}

	private function generate_elementor_widget($args){
		\PerchCanvas\Helper::xcopy(__DIR__.'/elementor', CTRL_AGENCY_TEMPLATEPATH.'admin/elementor');

		global $controlAgency;
		foreach ($controlAgency->sections as $filename => $section_id) {
			$class_file = CTRL_AGENCY_TEMPLATEPATH."admin/elementor/widgets/{$filename}.php";
			$search = [
				'CLASSNAME',
				'WIDGETID',
				'WIDGETCATEGORY',
				'WIDGETTITLE',
				'WIDGETICON',
				'RENDERFILENAME'
			];
			$replace = [
				str_replace(' ', '_', ucwords(str_replace('_', ' ', $section_id))),
				$section_id,
				'controlagency',
				$controlAgency->{$section_id}['title'],
				$controlAgency->{$section_id}['icon'],
				$filename
			];			
			$content = file_get_contents(__DIR__.'/elementor/widget.php');
			$content = str_replace($search, $replace, $content);
			file_put_contents($class_file, $content);
		}
		
	}


	public function resetSettings($args){
		if(empty($args['data']['option_name'])) die;
		$option_name = $args['data']['option_name'];
		if(delete_option($option_name)){
			$response = [
				'error' => 0,
				'redirect_to' => $_SERVER['HTTP_REFERER']
			];
			wp_send_json($response);
		}		
		
	}
   
}