<?php
namespace ControlAgency;

final class Post_Types{
    public $archive_pages = [];
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() { 
		add_action( 'init', [$this, 'register_post_type'] );  
        add_filter( 'manage_posts_columns', [$this, 'posts_columns'] );     
        add_filter( 'manage_posts_custom_column', [$this, 'posts_custom_column'] );   
        add_action( 'admin_bar_menu', [$this, 'admin_bar_menu'], 99 );  
        add_filter( 'enter_title_here', [$this, 'add_new_title'] );
        add_filter( 'gettext', [$this, 'excerpt_label'], 999, 2 );
	}

    public function register_post_type(){
        global $controlAgency;
        
        $disable_post_types = control_agency_option('disable_post_types', []); 
        foreach ($controlAgency->post_types as $post_type) {  
            if(empty($post_type) || in_array($post_type, $disable_post_types)) continue;

            $args = $controlAgency->{$post_type};
            $args = $this->archive_slug($post_type, $args);         
            $args = $this->single_slug($post_type, $args);         
            $args = $this->archive_title_description($post_type, $args);         
            register_post_type( $post_type, $args );
        }
        $controlAgency->archive_pages  = $this->archive_pages; 
        
    }

    private function archive_title_description($post_type, $args){
       
        $title = control_agency_option("{$post_type}_archive_page_title");
        $description = control_agency_option("{$post_type}_archive_page_desc");
        if(!empty($description)){
            $args['description'] = $description;
        }
        

        return $args;
    }

    private function single_slug($post_type, $args){
        $slug = control_agency_option("{$post_type}_single_page_slug");

        if(!empty($slug)){
            $args['rewrite']['slug'] = sanitize_title( $slug );
        }
        

        return $args;
    }

    private function archive_slug($post_type, $args){
        $new_slug = control_agency_option("{$post_type}_archive_page_slug");
        $slug = !empty($new_slug)? $new_slug : $post_type;

        $archive_page_id = control_agency_option("{$post_type}_archive_page");
        if(!empty($archive_page_id)){
            $archive_page = new \WP_Query(['post_type' => 'page', 'post_status' => 'publish', 'p'=> $archive_page_id]);
            if(!is_wp_error($archive_page) && $archive_page->found_posts > 0){
                $post = $archive_page->posts[0];
                $slug = $post->post_name;
                $this->archive_pages[$post_type] = $post->ID;
            }
        }
        
        if(!empty($slug)){
            $args['has_archive'] = sanitize_title( $slug );
        } 
        
        return $args;
    }

    public function posts_columns($columns){
        global $controlAgency;
        if(  in_array(get_post_type(), $controlAgency->post_types)){
            $columns['thumbnail'] = esc_attr_x('Thumbnail', 'Post type featured image label', 'control-agency');
        }
        return $columns;
    }

    public function posts_custom_column($column_name){
        if ( 'thumbnail' === $column_name ) {
            the_post_thumbnail( 'thumbnail' );
        }
    }

    public function admin_bar_menu(\WP_Admin_Bar $wp_admin_bar){
        if(is_admin()) return;

        global $controlAgency;
        $post_type = get_post_type();
        if(is_post_type_archive() && array_key_exists(get_post_type(), $controlAgency->archive_pages)){
            $key = array_flip($controlAgency->post_types)[$post_type];
            $args = Helper::include_admin_file("post-types/{$key}.php");

            $parent_slug = 'control-agency-edit-archive-page-link';
            $archive_page_title = $args['label'];
            $title = sprintf(esc_attr_x('Edit %s archive page', 'Admin bar archive page edit link', 'control-agency'), $archive_page_title);
            $wp_admin_bar->add_menu( array(
                'id'     => $parent_slug,               
                'title'  => $title,
                'href'   => admin_url('post.php?post='.$controlAgency->archive_pages[$post_type].'&action=edit'),                
            ) );
        }

    }

    public function add_new_title($title){
        global $current_screen, $controlAgency;
        $post_type = $current_screen->post_type;
        if  ( in_array($post_type, $controlAgency->post_types) && !empty($controlAgency->{$post_type}['labels']['add_new_title']) ) {
            $title = $controlAgency->{$post_type}['labels']['add_new_title'];
        }

        return $title;
    }

    public function excerpt_label( $translation, $original ) {
        global $current_screen, $controlAgency;      
        
        if(empty($current_screen->post_type)) return $translation;
        $post_type = $current_screen->post_type;
        
       if( !in_array($post_type, $controlAgency->post_types) ) return $translation;


        if ( !empty($controlAgency->{$post_type}['labels']['excerpt_label']) &&  'Excerpt' == $original ) {
            $translation = $controlAgency->{$post_type}['labels']['excerpt_label'];
        }

        if ( !empty($controlAgency->{$post_type}['labels']['excerpt_description']) && false !== strpos( $original, 'Excerpts are optional hand-crafted summaries of your' ) ) {
            $translation = $controlAgency->{$post_type}['labels']['excerpt_description'];
        }

        return $translation;
    }
}