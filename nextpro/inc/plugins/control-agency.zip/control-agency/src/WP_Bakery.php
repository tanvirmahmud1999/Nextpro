<?php
namespace ControlAgency;

final class WP_Bakery{

    private $prefix = 'control_agency_';
    
    private $category = 'Control Agency';

    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {
        $this->init();
        add_action( 'vc_before_init', [$this, 'integrateWithVC'] );        
	}

    
    private function init(){       
        
      // $this->category = control_agency_config('category');
    }

   

    public function integrateWithVC(){
        global $controlAgency;
        
        // WPB Elements      
        foreach ($controlAgency->sections as $element_id => $section_id) {
            $element = $controlAgency->{$section_id};
            if(!empty($element['disable_block'])) continue;
            
            $element = $this->clean_settings($element, $section_id);

            // required field
            $element['params'][] = $this->set_element_id($element_id);           
            vc_map($element);
        }
        
    }

    private function set_element_id($element_id){
        return [
            "type" => "textfield",           
            "heading" => '',
            "param_name" => "element_id",
            "value" => $element_id,
            "save_always" => true
        ];
    }
   
    private function clean_settings($element, $section_id){
        
        $element['base'] = $this->prefix.$section_id;
        unset($element['id']);

        $title = $element['title'];
        unset($element['title']);
        $element['name'] = esc_attr($title);        

        $desc = $element['description'];
        unset($element['description']);
        $element['description'] = wp_kses_post($desc);        
        $element['admin_enqueue_js'] = CTRL_AGENCY_ASSETS .'js/wpbakery.js';  
        $element['category'] = $this->category;        
           
        $element['class'] = str_replace('_', '-', $this->prefix).'element';
        $icon = $element['icon'];
        unset($element['icon']);
        $element['icon'] = str_replace('_', '-', $this->prefix).'icon'. ' '. $icon;

        if(!empty($element['fields'])){
            $fields = $element['fields'];
            unset($element['fields']);  
            $tabs = !empty($element['tabs'])? $element['tabs'] : [];
            unset($element['tabs']); 
            
            // Removed First tab item 
            array_shift($tabs);   
            $element['params'] = $this->clean_fields($fields, $tabs);   
            
        }  
        
        unset($element['supports']);
        unset($element['align']);

        return $element;
    }

    

    
    private function clean_fields($fields, $tabs = []){
        foreach ($fields as $key => $field) {
            $fields[$key] = $this->clean_field($field, $tabs);
        }
        return $fields;
    }
    

    private function clean_field($field, $tabs){

        if(!empty($field['id'])){
            $field['param_name'] = $field['id'];
            unset($field['id']);
        }

        if(!empty($field['name'])){
            $field['heading'] = $field['name'];
            unset($field['name']);
        }

        $field['description'] = '';
        if(!empty($field['desc'])){
            $field['description'] = $field['desc'];
            unset($field['desc']);
        }

        if(!empty($field['tab']) && !empty($tabs[$field['tab']])){
            $field['group'] = $tabs[$field['tab']];
            unset($field['tab']);
        }

        

        switch ($field['type']) {
            case 'text':
                if(!empty($field['clone']) && $field['clone']){
                    $field['type'] = 'textarea';
                    if(!empty($field['std'])){
                        $field['value'] = implode(",   ", $field['std']);                       
                    }
                    $field['holder'] = 'div';
                    $field['class'] = 'control-agency-holder';

                    $type_desc = sprintf('Note: A comma followed by 2 spaces %s is used to create spererate line or item of this field', "<code>',  '</code>");
                    $field['description'] = !empty($field['description'])? $field['description']."\n".$type_desc : $type_desc;
                }else{
                    $field['type'] = 'textfield';
                    if(!empty($field['std'])){
                        $field['value'] = $field['std'];
                       
                    }
                }
                unset($field['std']);
                
                break;
            case 'number':
                $field['type'] = 'textfield';
                if(!empty($field['std'])){
                    $field['value'] = $field['std'];
                    unset($field['std']);
                }
                break;    
            case 'hidden':
                $field['type'] = 'dropdown';
                if(!empty($field['std'])){
                    $field['value'] = ['Default' => $field['std']];
                }                
                break;    
            
            case 'textarea':
                if(!empty($field['std'])){
                    $field['value'] = $field['std'];
                    unset($field['std']);
                }
                break;

            case 'wysiwyg':
                $field['type'] = 'textarea';
                if(!empty($field['std'])){
                    $field['value'] = $field['std'];
                    unset($field['std']);
                }
                break;    

            case 'select':
                $field['type'] = 'dropdown';               
                if(!empty($field['options'])){
                    $field['value'] = array_flip($field['options']);
                    unset($field['options']);
                }
                break; 
            case 'icon':
                $field['type'] = 'textfield';
                if(!empty($field['std'])){
                    $field['value'] = $field['std'];
                    unset($field['std']);
                }
                break;        

            case 'image_advanced':
                if(!empty($field['max_file_uploads']) && ($field['max_file_uploads'] > 1)){
                    $field['type'] = 'attach_images';
                }else{
                    $field['type'] = 'attach_images';
                }
                break; 

            case 'single_image':                
                $field['type'] = 'attach_image';              
                break;  

            case 'file_input':                
                $field['type'] = 'attach_image';              
                break;    

            case 'color':                
                $field['type'] = 'colorpicker';  
                if(!empty($field['std'])){
                    $field['value'] = $field['std'];
                    unset($field['std']);
                }            
                break;        

            case 'group':
                if(isset($field['clone']) && !$field['clone']){
                    $field['type'] = 'textarea';
                    if(!empty($field['std']) && is_array($field['std'])){                        
                        $field['value'] = implode(",  ", $field['std']);  
                        unset($field['std']);                     
                    }
                    
                    $field['holder'] = 'div';
                    $field['class'] = 'control-agency-holder';

                    $type_desc = sprintf('Note: A comma followed by 2 spaces %s is used to create spererate line or item of this field', "<code>',  '</code>");
                    $field['description'] = !empty($field['description'])? $field['description']."\n".$type_desc : $type_desc;
                }else{
                    $field = $this->configure_group_field($field);
                }
                
                
                break; 
            default:
                # code...
                break;
             
        }

        if(!empty($field['param_name'])):
            if(in_array($field['param_name'], ['title', 'subtitle']) && ($field['type'] != 'param_group')){
                $field['admin_label'] = true;
            }
            
            if($field['param_name'] == 'template'){
                $field['save_always'] = true;
            }   
        endif;
        

        if(!empty($field['visible'])){            
            $field['dependency'] = $this->clean_condition($field['visible']);
        }

        return $field;
    }

    private function configure_group_field($field){
        $field['type'] = 'param_group';
        $fields = $field['fields'];
        $params = $this->clean_fields($fields);
        if(!empty($field['group_title'])){
            foreach ($params as $key => $param) {
                if(str_contains($field['group_title'], $param['param_name'])){
                    $param['admin_label'] = true;
                }
                if(str_contains($field['group_title'], '_text')){
                    $field['admin_label'] = true;
                }
                $params[$key] = $param;
            }
        }
        $field['params'] = $params;

        if(empty($field['std'])){
            $field['std'] = array_column($fields, 'value', 'id');
        }
        
        
        if(!empty($field['std'])){
            foreach ($field['std'] as $key => $value) {
               
                if(empty($value) || !is_array($value)) continue;
                foreach ($value as $_key => $_value) {
                    if(is_array($_value)){
                        $_value = implode(',', $_value);
                    }
                    $value[$_key] = $_value;
                }
                $field['std'][$key] = $value;
            }
            $field['value'] = rawurlencode( wp_json_encode($field['std']));
            
        }

        unset($field['fields']);
        unset($field['std']);
        return $field;
    }

    private function clean_condition($condition = []){
        if(!empty($condition[0]) && !is_array($condition[0])){
            $condition = [
                'element' => $condition[0],
                'value' => !empty($condition[2])? (array)$condition[2] : false,
            ];
        }else{
            $condition = [];
        }
        return $condition;
    }
    
}