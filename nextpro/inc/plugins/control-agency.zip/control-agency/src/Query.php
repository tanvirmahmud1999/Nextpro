<?php
namespace ControlAgency;

final class Query{

    public function __construct() {    
        
        add_filter('query_vars', [$this, 'query_vars']);
        add_action( 'pre_get_posts', [$this, 'pre_get_posts'] );
	}

    public function query_vars($qvars){
        foreach ($this->get_query_vars() as $query_var => $value) {
            if(empty($value)) continue;
            $qvars[] = esc_attr($query_var);
        }
        return $qvars;
    }

    

    public function pre_get_posts( $query ) { 
        if(empty($query->query['post_type'])) return;

        global $controlAgency; 
        $post_type = $query->query['post_type'];
        
        if ( !is_admin() && $query->is_main_query() && in_array($post_type , $controlAgency->post_types) ) {

            $query_args = control_agency_option("{$post_type}_archive_query");
            if( !empty($query_args) ){
                foreach ($query_args as $key => $value) {
                    if(empty($value) || ($key == 'tax_query')) continue;
                    $query->set( $key, $value );
                }
            }

            $tax_query = [];
            if( !empty($query_args['tax_query']) ){
                foreach ($query_args['tax_query'] as $key => $value) {
                    if(is_string($value)) continue;
                    if(!empty($value['terms'])){
                        $tax_query[] = $value;
                    }
                }
            }
            if(!empty($tax_query)){
                $query->set( 'tax_query', $tax_query );
            }
            
          
            
            foreach ($this->get_query_vars() as $query_var => $value) { 
                if(empty(get_query_var($query_var)) || empty($value)) continue;
                $this->filter_query_var($query_var, $query);                
            }    
            
        }  
        
      
        
        
    }  
    
     
    public function filter_query_var($query_var, $query){
        $method = 'filter_query_'.$query_var;            
        if(method_exists($this, $method )){
            $this->$method($query);                    
        }else{
            do_action('control_projects'.$method, $query); // Depreciated It will removed after 1.1
        }
        
        do_action('control_agency_query_by_'.$method, $query);
    }
    

    public function get_query_vars(){
        return apply_filters('control_agency_filter_query_vars', [
            'terms' => esc_attr__('Search', 'control-agency'),
            'sort' => esc_attr__('Sort', 'control-agency'),
            'view' => esc_attr__('View', 'control-agency'),
        ]);
        
    }
    
}