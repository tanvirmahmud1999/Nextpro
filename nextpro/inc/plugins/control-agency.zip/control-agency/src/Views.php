<?php
namespace ControlAgency;

final class Views{
    
    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {  
        add_action( 'init', [$this, 'load_theme_functions_file'], -999 );   
        add_filter( 'archive_template', [$this, 'archive_template'] );
        add_filter( 'taxonomy_template', [$this, 'taxonomy_template'] );
        // add_filter( 'search_template', [$this, 'archive_template'] );
        add_filter( 'single_template', [$this, 'single_template'] );
	}

    public function load_theme_functions_file(){
        $template_file = control_agency_template('functions.php');
        if($template_file){
            include $template_file;
        }
    }


    public function archive_template( $template ) {
        global $controlAgency;
        // Post type archives
        if(in_array(get_post_type(), $controlAgency->post_types)){
            $template_file = control_agency_template('archive.php');
        }
       
        
        if ( !empty($template_file) && file_exists($template_file) ) {
            $template = $template_file;
        }

        
        return $template;
    }


    public function taxonomy_template( $template ) {
        global $controlAgency;
        if(in_array(get_post_type(), $controlAgency->taxonomies)){
                $template_file = control_agency_template('taxonomy.php');
        }
        
        
        if ( !empty($template_file) && file_exists($template_file) ) {
            $template = $template_file;
        }

        
        return $template;
    }


    public function single_template( $template ) {       
        global $controlAgency;
        if( in_array(get_post_type(), $controlAgency->post_types) ){
            $template_file = control_agency_template('single.php');
        }
        
        if ( !empty($template_file) && file_exists($template_file) ) {
            $template = $template_file;
        }
       
        return $template;
    }

   
    
}