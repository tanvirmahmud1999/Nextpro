<?php
namespace ControlAgency;

final class Elementor{

    
    private $prefix = 'control_agency_';
    private $category = 'Control Agency';
    private $category_slug = 'controlagency';

    /**
	 * Add hooks when module is loaded.
	 */
	public function __construct() {
        add_action( 'elementor/elements/categories_registered', [$this, 'widget_categories'] );
        add_action( 'elementor/editor/before_enqueue_styles', [$this, 'editor_enqueue_styles'] );
        add_action( 'elementor/widgets/register', [$this, 'register_widgets'] );
        add_action( 'elementor/element/before_section_start', [$this, 'inject_custom_control'], 10, 3 );
	}

    public function widget_categories( $elements_manager ) {

        $elements_manager->add_category(
            $this->category_slug,
            [
                'title' => $this->category,
                'icon' => 'fa fa-plug',
            ]
        );        
    
    }

    public function editor_enqueue_styles(){
        wp_enqueue_style( 'dashicons' );
    }

    public function register_widgets($widgets_manager){

        global $controlAgency;
		foreach ($controlAgency->sections as $filename => $section_id) {
            $class_file = CTRL_AGENCY_TEMPLATEPATH."admin/elementor/widgets/{$filename}.php";
            if(!file_exists($class_file)) continue;
            
            require_once $class_file;
            $class_name = str_replace(' ', '_', ucwords(str_replace('_', ' ', $section_id)));
            $full_class_name = "\\ControlAgency\\Elementor\\{$class_name}";
            if (class_exists($full_class_name)) {
                $widgetObj = new $full_class_name();
                $widgets_manager->register($widgetObj);
            }
        }
        
    }

    /**
     * @param \Elementor\Controls_Stack $element    The element type.
     * @param string                    $section_id Section ID.
     * @param array                     $args       Section arguments.
     */
    function inject_custom_control( $element, $section_id, $args ) {

        if ( 'control-agency-fields' === $section_id ) {
            global $controlAgency;
            $block_id = $args['widget_id'];
            $block = !empty($block_id)? $controlAgency->{$block_id} : [];
            if(empty($block)){
                Helper::debug_log("{$block_id} not found for {$section_id}");
                Helper::debug_log($element);
                Helper::debug_log($args);
                return;
            }
            
            $element->start_controls_section(
                $block['id'],
                [
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'label' => $block['title'],
                ]
            );

        
            // Fields goes here
            if(!empty($controlAgency->{$block_id}['fields'])){
                $fields = $controlAgency->{$block_id}['fields'];
                foreach ($fields as $field) {
                    $_field = new Elementor_Field($field);   
                    $_field_args =   $_field->data;
                    unset($_field_args['name']);              
                    $element->add_control( $_field->data['name'], $_field_args );
                    Helper::debug_log($_field_args);
                }
            }

            $element->end_controls_section();

        }

    }

    
    
}