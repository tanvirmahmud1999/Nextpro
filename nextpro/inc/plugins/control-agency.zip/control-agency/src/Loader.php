<?php
namespace ControlAgency;

final class Loader{

    /**
     * Add hooks when module is loaded.
     */
    public function __construct(){
        add_filter( 'plugin_action_links_control-agency/control-agency.php', [ $this, 'plugin_links' ], 20 );
        add_filter( 'plugin_row_meta', [ $this, 'row_meta' ], 10, 2 );
        $this->init();
    }

    private function init(){
        // 1. setup global variable
        $GLOBALS['controlAgency'] = new Setup;

        // 2. common 
        new Assets;
        new Ajax;
       
        // 3. posts
        new Post_Types;
        new Taxonomies;        

        // 4. meta settings
        new Blocks;
        new Meta_Boxes;
        new Settings;

        // Frontend
        new Query;
        new Views;
        new Templates;
        new Shortcodes;

        // global addoons
        new Social_Share;

        // third party plugin support
        new WP_Bakery; 
        new Elementor;
        
    }
    

    public function plugin_links( array $links ) : array {
        $link = admin_url('options-general.php?page=control-agency');
        if(current_theme_supports('control-agency')){
            $link = admin_url('themes.php?page=control-agency');
        }
        $links[] = '<a href="'.esc_url($link).'">' . esc_html__( 'Settings', 'control-agency' ) . '</a>';
		
		return $links;
	}

    public function row_meta( $links, $file ) {    
        if ( 'control-agency/control-agency.php' == $file ) {
            $links[] = '<a target="_blank" href="https://github.com/themeperch/control-agency/wiki">' . esc_html__( 'Wiki', 'control-agency' ) . '</a>';
            $links[] = '<a target="_blank" href="https://themeperch.net/contact">' . esc_html__( 'Support', 'control-agency' ) . '</a>';
        }
        return (array) $links;
    }
    
}