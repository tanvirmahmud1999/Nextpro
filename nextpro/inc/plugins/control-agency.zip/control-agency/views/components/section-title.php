<?php ob_start(); ?>
<div class="section-title ca-testimonial<?php echo (empty($enable_section_title_button) && !empty($css_class))? ' '.$css_class : '' ?>">
    <?php                                 
        control_agency_content($name, '<p class="name">', '</p>');

        $title  = control_agency_parse_text($title, ['class' => 'ca-underline ca-underline-success', 'atts' => 'data-ca-animation:bgLeftToRight']);
        control_agency_content($title, '<h2 class="title fs-1">', '</h3>');

        $subtitle  = control_agency_parse_text($subtitle, ['tagclass' => 'fw-bold']);
        control_agency_content($subtitle, '<p class="subtitle lead">', '</p>');          
    ?>        
</div>
<?php $section_title = ob_get_clean(); ?>    

<?php 
if(!empty($enable_section_title_button)): ?>
    <div class="section-title-btn ca-testimonial-btn <?php echo !empty($css_class)? ' '.$css_class : '' ?>">  
        <?php echo do_shortcode($section_title); ?>
        <?php 
        if(!empty($buttons)): ?>
            <div class="d-flex flex-wrap gap-2">
                <?php
                foreach ($buttons as $button) {
                    extract(wp_parse_args($button, [
                        'btn_title' => '',
                        'btn_url' => '',
                        'btn_target' => '',
                        'btn_class' => '',
                    ]));
                    if(empty($btn_title) || empty($btn_url)) continue;
                    printf('<a href="%1$s" class="btn %3$s"%4$s>%2$s</a>', 
                        esc_url($btn_url), 
                        esc_attr($btn_title), 
                        esc_attr($btn_class),
                        !empty($btn_target)? ' target="'.esc_url($btn_target).'"' : ''
                    );
                }
                ?>
            </div>
            <?php 
        endif;
        ?>
        
    </div>
    <?php 
else: 
 echo do_shortcode($section_title); 
endif; 
?>