<?php if(empty($desc)) return; ?>
<div class="testimonial ca-testimonial">                                   
    <div class="content-testimonial p-5 border rounded mb-4 <?php echo esc_attr($css_class) ?>">        
        <?php control_agency_content($title, '<h4 class="title-testimonial">', '</h4>') ?>    
        <?php control_agency_render_template('components/ratings.php', ['ratings' => $ratings, 'size' => '1.5rem']) ?>     
        <?php control_agency_content($desc, '<p class="desc-testimonial lead fw-normal">', '</p>') ?>                                    
    </div>
    <div class="testimonial-info d-flex gap-3">
        <?php 
        if( !empty($image) ){
            printf('<img src="%s" alt="%s" class="object-fit-cover rounded-circle" width="90" height="90" />', esc_url($image), $name);
        }
        ?>
        <div class="pt-3">
            <?php control_agency_content($name, '<h5 class="mb-0">', '</h5>') ?>
            <?php control_agency_content($designation, '<p class="fst-italic">', '</p>') ?>
        </div>
    </div>                                
</div>