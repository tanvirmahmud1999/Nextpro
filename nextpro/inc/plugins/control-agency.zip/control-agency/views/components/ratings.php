<?php 
if(empty($ratings) && !is_numeric($ratings)) return; 
$style = !empty($size)? " style='--ca-rating-size: {$size};'" : '';
?>
<div class="ca-star-ratings"<?php echo $style; ?>>
    <span class="star-rating">										
        <span class="star-fill" style="width: <?php echo $ratings*100 / 5 ?>%;"></span>
    </span>
</div>