document.addEventListener("DOMContentLoaded", function () {
    if (document.readyState === 'complete') {
        controlAgencyObserveAnimations();
    } else {
        document.addEventListener('readystatechange', function() {
            if (document.readyState === 'complete') {
                controlAgencyObserveAnimations();
            }
        });
    }
});

function controlAgencyObserveAnimations() {
    const elements = document.querySelectorAll('[data-ca-animation]');
    const options = {
        rootMargin: '0px',
        threshold: 0.5
    };

    const observer = new IntersectionObserver(function(entries, observer) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                const animationName = element.getAttribute('data-ca-animation');
                const animationDuration = element.getAttribute('data-ca-duration');
                const animationDelay = element.getAttribute('data-ca-delay');
                
                if (animationName) {
                    element.classList.add('ca-'+animationName);
                    element.classList.add('ca-animated');
                    element.style.animationName = animationName;
                    
                    if (animationDuration) {
                        element.style.animationDuration = animationDuration;
                    }
                    
                    if (animationDelay) {
                        element.style.animationDelay = animationDelay;
                    }
                }
                
                observer.unobserve(element);
            }
        });
    }, options);

    elements.forEach(element => {
        const animationDuration = element.getAttribute('data-ca-duration');
        const animationDelay = element.getAttribute('data-ca-delay');
        
        if (element.getAttribute('data-ca-animation')) {
            observer.observe(element);
        }
    });
}
