<?php
echo do_shortcode($page_content);