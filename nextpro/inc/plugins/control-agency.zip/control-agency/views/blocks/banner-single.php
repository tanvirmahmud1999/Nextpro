
<div class="row align-items-center border-bottom">
    <div class="col-lg-6">
        <div class="content-banner py-5">
            <?php 
            $title = str_replace('[post_title]', get_the_title(), $title);
            $subtitle = str_replace('[post_excerpt]', get_the_excerpt(), $subtitle);
            control_agency_content($title, '<h1 class="display-4 fw-bold lh-1 text-body-emphasis">', '</h1>'); 
            control_agency_content($subtitle, '<p class="lead">', '</p>');
            ?>
            
            <?php if( !empty($buttons) ): ?>
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4 mb-lg-3">
                <?php 
                foreach ($buttons as $key => $button) {
                    if(empty($button['text']) || empty($button['url'])) continue;
                    printf('<a href="%2$s" class="btn btn-lg px-4 me-md-2 fw-bold %3$s"%4$s>%1$s</a>', 
                    esc_attr($button['text']), 
                    esc_url($button['url']), 
                    esc_attr($button['class']),
                    !empty($button['target'])? ' target="_blank"' : ''
                );
                } 
                ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-5 offset-lg-1">
        <?php 
        $image_url = control_agency_file_uri('assets/images/banner.png');
       
        $image_url = control_agency_get_attachment_url($image, 'full', $image_url); 
        if(!empty($image_url)){
            printf('<img class="ca-lazy img-fluid" src="%1$s" data-src="%1$s" alt="%2$s" width="500" height="587" />', $image_url, control_agency_get_title());
        }
        ?>
        
    </div>
</div>
<?php control_agency_enqueue_style('assets/css/banner.css') ?>