<section class="section-testimonials py-5">
    <div class="container">
        <?php
        $section_title_args = wp_parse_args($args, [
            'name' => '',
            'title' => '',
            'subtitle' => '',
            'enable_section_title_button' => false,
            'buttons' => '',
            'css_class' => 'mb-4',
        ]);
        control_agency_render_template('components/section-title.php', $section_title_args);
        ?>
        
        <?php 
        $unique_id = uniqid('testimonials-');
        if(!empty($testimonials_group)): ?>
            <div id="<?php echo esc_attr($unique_id); ?>" class="carousel carousel-testimonials slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php 
                    foreach ($testimonials_group as $key => $testimonial): ?>
                        <div class="carousel-item<?php echo $key == 0? ' active': ''; ?>">
                            <?php 
                            $testimonial_args = wp_parse_args($testimonial, [
                                'title' => '',
                                'desc' => '',
                                'ratings' => '',
                                'image' => '',
                                'name' => '',
                                'designation' => '',
                                'css_class' => 'rounded arrow-bottom-start',
                            ]);
                            control_agency_render_template('components/testimonial.php', $testimonial_args);
                            ?>
                        </div>
                        <?php 
                    endforeach; ?>                 
                </div>

                <div class="next-prev-buttons next-prev-buttons-testimonials position-relative text-end ctrlagency-mtn-80 pb-5">
                    <a class="control-prev" href="#<?php echo esc_attr($unique_id); ?>" data-bs-slide="prev">
                        <?php echo control_agency_get_icon_svg('ui', 'prev', 24) ?>
                        <span class="visually-hidden">Previous</span>
                                </a>
                    <a class="control-next" href="#<?php echo esc_attr($unique_id); ?>" data-bs-slide="next">
                        <?php echo control_agency_get_icon_svg('ui', 'next', 24) ?>
                        <span class="visually-hidden">Next</span>
                    </a>
                </div>
            </div>
            <?php 
        endif; ?>
    </div>
</section>
<?php control_agency_enqueue_style('assets/css/testimonials.css') ?>