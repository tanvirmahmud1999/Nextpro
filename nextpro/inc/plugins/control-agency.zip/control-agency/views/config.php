<?php
return [
    'project_data_title' => esc_attr__('Project data', 'control-agency'),
    'client_name' => 'Themeperch',
    'website' => 'https://themeperch.net',
    'shortcode_prefix' => 'control_agency_',
    'category' => 'Control Agency',
];