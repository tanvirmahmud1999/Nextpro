<div class="postbox-sidebar">
    <div class="postbox-header-sidebar">
        <h2>Support & Licensing</h2>
    </div>
    <div class="inside">
        <div class="inside-sidebar">
            <p>Welcome to the settings page for <strong>Control Agency</strong>! Customize your plugin experience below.</p>
            <ul>
                <li><label><input type="password" name="license_key" placeholder="Activate License Key"></li>
                <li><label>Default Language: <select name="default_language">
                    <option value="english">English</option>                   
                </select></label></li>
            </ul>
            
            <strong>Notifications</strong>
            <ul>
                <li><label><input type="checkbox" name="email_notifications"> Email Notifications</label></li>
                <li><label><input type="checkbox" name="desktop_notifications"> Desktop Notifications</label></li>
            </ul>

            <strong>Advanced</strong>
            <ul>
                <li><label><input type="checkbox" name="debug_mode"> Debug Mode</label></li>
                <li><label>Data Usage: <input type="text" name="data_usage"></label></li>
            </ul>

        </div>
    </div>
</div>