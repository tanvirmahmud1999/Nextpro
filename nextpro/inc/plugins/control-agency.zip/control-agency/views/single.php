<?php
get_header();

control_agency_post_type_content();   

get_footer();