<?php
use ControlUserProfile\Support\Arr;

/**
 * No longer needed. Keep it here for backward compatibility.
 */
class CUP_Helpers_Array extends Arr {}
