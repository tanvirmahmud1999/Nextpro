<?php
namespace ControlUserProfile\UserProfile;

class ForcePasswordChangeSettings {
	public function __construct() {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	public function register_settings() {
		add_settings_section( 'mb-user-profile-settings', '', '', 'general' );

		add_settings_field(
			'mbup_force_password_change',
			__( 'Force password change', 'mb-user-profile' ),
			[ $this, 'render_filed' ],
			'general',
			'mb-user-profile-settings',
			[ 'mbup_force_password_change' ]
		);
		register_setting( 'general', 'mbup_force_password_change', 'esc_attr' );
	}

	public function render_filed( $args ) {
		printf(
			'<label><input type="checkbox" name="%1$s" value="1"%2$s> %3$s</label>',
			esc_html( $args[0] ),
			checked( get_option( $args[0] ), 1, false ),
			esc_html__( 'Force users to change the passwords for the first login', 'mb-user-profile' )
		);
	}
}
