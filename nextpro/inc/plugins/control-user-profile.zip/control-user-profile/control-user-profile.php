<?php
/**
 * Plugin Name: Control User Profile
 * Plugin URI:  https://metabox.io/plugins/mb-user-profile/
 * Description: Register, edit user profiles with custom fields on the front end.
 * Version:     1.0.0
 * Author:      Senseflame
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: control-user-profile
 * Domain Path: /languages/
 *
 * @package    Meta Box
 * @subpackage MB User Profile
 */

// Prevent loading this file directly.
defined( 'ABSPATH' ) || die;

if ( ! function_exists( 'cup_user_profile_load' ) ) {
	if ( file_exists( __DIR__ . '/vendor' ) ) {
		require __DIR__ . '/vendor/autoload.php';
		require __DIR__ . '/vendor/meta-box/mb-user-meta/mb-user-meta.php';
	}
	
	require_once dirname( __FILE__ ) . '/src/Shortcodes.php';
	require_once dirname( __FILE__ ) . '/src/ConfigStorage.php';
	require_once dirname( __FILE__ ) . '/src/Forms/Factory.php';
	require_once dirname( __FILE__ ) . '/src/Forms/Base.php';
	require_once dirname( __FILE__ ) . '/src/Forms/Register.php';
	require_once dirname( __FILE__ ) . '/src/Forms/Login.php';
	require_once dirname( __FILE__ ) . '/src/Forms/Info.php';
	require_once dirname( __FILE__ ) . '/src/Arr.php';
	require_once dirname( __FILE__ ) . '/src/array.php';
	require_once dirname( __FILE__ ) . '/src/Appearance.php';
	require_once dirname( __FILE__ ) . '/src/User.php';


	require_once dirname( __FILE__ ) . '/src/DefaultFields.php';
	require_once dirname( __FILE__ ) . '/src/UserFields.php';
	require_once dirname( __FILE__ ) . '/src/Email.php';
	require_once dirname( __FILE__ ) . '/src/ForcePasswordChangeSettings.php';
	require_once dirname( __FILE__ ) . '/src/class-gamajo-template-loader.php';
	require_once dirname( __FILE__ ) . '/src/TemplateLoader.php';

	/**
	 * Hook to 'init' with priority 5 to make sure all actions are registered before Meta Boxes runs.
	 */
	add_action( 'init', 'cup_user_profile_load', 5 );

	/**
	 * Load plugin files after Meta Box is loaded
	 */
	function cup_user_profile_load() {
		if ( ! defined( 'CTRLBP_VER' ) ) {
			return;
		}

		define( 'CUP_URL', __DIR__ );
		define( 'CUP_VER', '1.0.0' );
		define( 'CUP_DIR', __DIR__ );

		$languages_dir = trim( str_replace( wp_normalize_path( WP_PLUGIN_DIR ), '', wp_normalize_path( __DIR__ . '/languages' ) ), '/' );
		load_plugin_textdomain( 'control-user-profile', false, $languages_dir );

		new ControlUserProfile\UserProfile\DefaultFields;
		new ControlUserProfile\UserProfile\UserFields;
		new ControlUserProfile\UserProfile\Email;
		new ControlUserProfile\UserProfile\Shortcodes;
		new ControlUserProfile\UserProfile\ForcePasswordChangeSettings;

		// Add dependency notice in AIO.
		if ( class_exists( 'MetaBox\Dependency\Plugins' ) ) {
			new MetaBox\Dependency\Plugins( 'MB User Profile', [
				[
					'name'     => 'MB User Meta',
					'function' => 'cup_user_meta_load',
				],
			], [
				// Translators: %1$s - the plugin name, %2$s - extensions, %3$s - action.
				'message'  => __( '%1$s requires %2$s to function correctly. %3$s.', 'control-user-profile' ),
				'activate' => __( 'Activate now', 'control-user-profile' ),
			] );
		}
	}
}
